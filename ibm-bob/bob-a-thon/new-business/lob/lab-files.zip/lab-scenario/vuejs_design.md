# Sales Navigator — Vue.js フロントエンド設計書

## 1. システム概要

### 1.1 背景と目的
本設計書は、既存の静的HTML/Vanilla JSで実装された営業支援CRMアプリケーション（`index.html`）を、保守性・拡張性・再利用性に優れた **Vue.js (Vue 3 + TypeScript + Composition API + Pinia + Vue Router)** アーキテクチャにリファクタリング・モダナイズするためのフロントエンド設計書です。

### 1.2 アプリケーション概要
- **アプリケーション名**: Sales Navigator（営業支援 CRM）
- **主要目的**: 営業担当者が顧客情報、商談進捗、対応履歴、次回アクション、および提案レコメンデーションを一元管理・閲覧できるフロントエンドSPA（シングルページアプリケーション）。

---

## 2. 技術スタック・選定技術

| カテゴリ | 採用技術 | バージョン / 選定理由 |
| :--- | :--- | :--- |
| **Framework** | Vue.js 3 | Composition API (`<script setup>`) による高い型親和性とロジック分離 |
| **Language** | TypeScript | 型安全性の確保、データ構造の明文化 |
| **State Management** | Pinia | 直感的で型推論が効く公式推奨状態管理ライブラリ |
| **Routing** | Vue Router 4 | SPAでの画面遷移、パラメータ（顧客ID等）ハンドリング |
| **Build Tool** | Vite | 高速な開発環境・ビルドパイプライン |
| **Styling** | CSS Modules / Scoped CSS / CSS Variables | 既存のデザインシステム（ダークトーンカラーパレット、IBM Plex Sans JP）を継承 |
| **Code Quality** | ESLint + Prettier | コードスタイル統一 |

---

## 3. ディレクトリ構成

```text
src/
├── assets/
│   ├── styles/
│   │   ├── variables.css      # カラー、フォント、余白などのグローバルCSS変数
│   │   ├── base.css           # リセットCSS、ベースタイポグラフィ
│   │   └── main.css           # グローバルエントリースタイル
├── components/
│   ├── common/
│   │   ├── AppBadge.vue       # ステータスバッジ (商談中/成約済み/フォローアップ中)
│   │   ├── AppAvatar.vue      # 顧客イニシャルアバター
│   │   ├── AppHeader.vue      # ヘッダー (ロゴ・タイトル)
│   │   └── AppSidebar.vue     # サイドバーナビゲーション
│   ├── customer/
│   │   ├── CustomerCard.vue   # 顧客一覧カード
│   │   ├── CustomerFilter.vue # ステータスフィルターボタングループ
│   │   ├── CustomerSearch.vue # 検索バー
│   │   ├── CustomerInfo.vue   # 顧客基本情報グリッド
│   │   ├── CustomerTimeline.vue # 対応履歴タイムライン
│   │   ├── NextActionCard.vue # 次回アクションカード
│   │   └── RecommendationList.vue # AI/提案レコメンドリスト
│   └── placeholder/
│       └── PlaceholderView.vue # ダッシュボード/設定等の準備中画面共通コンポーネント
├── layouts/
│   └── DefaultLayout.vue      # サイドバーとヘッダーを含む共通レイアウト
├── router/
│   └── index.ts               # ルーティング定義
├── stores/
│   └── customer.ts            # 顧客データ管理・フィルタリング・検索ストア
├── types/
│   └── customer.ts            # 顧客モデル・ステータス等のTypeScriptインターフェース
├── views/
│   ├── CustomerListView.vue   # 顧客一覧画面
│   ├── CustomerDetailView.vue # 顧客詳細画面
│   ├── DashboardView.vue      # ダッシュボード画面 (プレースホルダー)
│   └── SettingsView.vue       # 設定画面 (プレースホルダー)
├── App.vue                    # ルートコンポーネント
└── main.ts                    # エントリーポイント
```

---

## 4. データモデル・型定義 (`types/customer.ts`)

```typescript
export type CustomerStatus = '商談中' | '成約済み' | 'フォローアップ中';
export type FilterStatus = 'all' | CustomerStatus;

export interface HistoryItem {
  date: string;
  text: string;
}

export interface RecommendationItem {
  title: string;
  desc: string;
}

export interface Customer {
  id: number;
  name: string;
  age: number;
  company: string;
  industry: string;
  status: CustomerStatus;
  email: string;
  history: HistoryItem[];
  nextAction: string;
  recs: RecommendationItem[];
}
```

---

## 5. 状態管理設計 (`stores/customer.ts`)

Pinia を使用し、顧客データの状態管理、検索クエリ、フィルタ状態を集約します。

### 5.1 State
- `customers: Customer[]`: 全顧客リスト
- `currentFilter: FilterStatus`: 現在選択中のステータスフィルタ（初期値: `'all'`）
- `searchQuery: string`: 検索キーワード文字列（初期値: `''`）
- `isLoading: boolean`: ローディング状態フラグ

### 5.2 Getters (Computed)
- `filteredCustomers`: `currentFilter` および `searchQuery` に基づいて絞り込まれた顧客リスト。
- `filteredCount`: 絞り込み後の件数。
- `getCustomerById(id: number)`: 指定IDの顧客情報を取得するセレクタ。

### 5.3 Actions
- `setFilter(filter: FilterStatus)`: フィルタの更新。
- `setSearchQuery(query: string)`: 検索クエリの更新。
- `fetchCustomers()`: API / モックからのデータ取得。

---

## 6. ルーティング設計 (`router/index.ts`)

| パス | 名前 | コンポーネント | 説明 |
| :--- | :--- | :--- | :--- |
| `/` | `customers` | `CustomerListView.vue` | 顧客一覧（トップ） |
| `/customers/:id` | `customer-detail` | `CustomerDetailView.vue` | 顧客詳細 |
| `/dashboard` | `dashboard` | `DashboardView.vue` | ダッシュボード（準備中） |
| `/settings` | `settings` | `SettingsView.vue` | 設定（準備中） |

---

## 7. 画面およびコンポーネント詳細設計

### 7.1 共通レイアウト (`DefaultLayout.vue`)
- **ヘッダー (`AppHeader.vue`)**:
  - ロゴマーク（SVG）、システム名「Sales Navigator」、サブタイトル「営業支援 CRM」を表示。
- **サイドバー (`AppSidebar.vue`)**:
  - メニューアイテム（顧客リスト `/`、ダッシュボード `/dashboard`、設定 `/settings`）。
  - ルーターの現在パス (`$route.path`) と連動してアクティブスタイル（`class="nav-item active"`）を適用。

### 7.2 顧客一覧画面 (`CustomerListView.vue`)
- **ヘッダー部**: 
  - タイトル「顧客リスト」および該当件数バッジ（`count-label`）の表示。
- **ツールバー部**:
  - `CustomerSearch.vue`: 顧客名リアルタイム検索テキストボックス（`v-model="store.searchQuery"`）。
  - `CustomerFilter.vue`: 「すべて」「商談中」「成約済み」「フォローアップ中」のボタングループ。
- **グリッド表示部**:
  - レスポンシブグリッドレイアウト（3列 → 2列 → 1列）。
  - `CustomerCard.vue` の一覧レンダリング（`v-for="c in filteredCustomers" :key="c.id"`）。
  - クリックまたはキーボード操作（Enter/Space）で `router.push({ name: 'customer-detail', params: { id: c.id } })` へ遷移。
- **空状態表示 (`EmptyState`)**:
  - 条件に一致する顧客が0件の場合のメッセージとアイコン表示。

### 7.3 顧客詳細画面 (`CustomerDetailView.vue`)
- **戻るナビゲーション**:
  - 一覧へ戻るボタン（`<router-link to="/">` または `router.back()`）。
- **詳細ヘッダーカード (`detail-card-header`)**:
  - ラージアバター（`AppAvatar.vue size="lg"`）、顧客名、ステータスバッジ（`AppBadge.vue`）、会社名・業種。
- **基本情報グリッド (`CustomerInfo.vue`)**:
  - 年齢、業種、会社名、メールアドレス（`mailto:` リンク）。
- **タイムライン部 (`CustomerTimeline.vue`)**:
  - 対応履歴の日付と内容を縦軸タイムライン形式で表示。
- **次回アクション部 (`NextActionCard.vue`)**:
  - カレンダーアイコン付きの次回アクション予告カード。
- **レコメンド部 (`RecommendationList.vue`)**:
  - 番号付きレコメンドカードリスト（提案タイトル・詳細説明）。

---

## 8. コンポーネント実装仕様（主要例）

### 8.1 ステータスバッジコンポーネント (`AppBadge.vue`)
```vue
<script setup lang="ts">
import { computed } from 'vue';
import type { CustomerStatus } from '@/types/customer';

const props = defineProps<{
  status: CustomerStatus;
}>();

const badgeClass = computed(() => {
  switch (props.status) {
    case '成約済み':
      return 'badge-green';
    case 'フォローアップ中':
      return 'badge-yellow';
    default:
      return 'badge-blue';
  }
});
</script>

<template>
  <span :class="['badge', badgeClass]">
    <span class="badge-dot"></span>
    {{ status }}
  </span>
</template>

<style scoped>
.badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 11px;
  font-weight: 500;
  padding: 3px 8px;
  border-radius: 20px;
}
.badge-blue   { background: #0f2050; color: #7eb8f7; }
.badge-green  { background: #0d2e1a; color: #4caf82; }
.badge-yellow { background: #2e2400; color: #f0c060; }
.badge-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}
.badge-blue .badge-dot   { background: #7eb8f7; }
.badge-green .badge-dot  { background: #4caf82; }
.badge-yellow .badge-dot { background: #f0c060; }
</style>
```

### 8.2 顧客カードコンポーネント (`CustomerCard.vue`)
```vue
<script setup lang="ts">
import type { Customer } from '@/types/customer';
import AppBadge from '@/components/common/AppBadge.vue';
import AppAvatar from '@/components/common/AppAvatar.vue';

defineProps<{
  customer: Customer;
}>();

const emit = defineEmits<{
  (e: 'select', id: number): void;
}>();
</script>

<template>
  <div
    class="customer-card"
    tabindex="0"
    role="button"
    :aria-label="`${customer.name}の詳細を表示`"
    @click="emit('select', customer.id)"
    @keydown.enter="emit('select', customer.id)"
    @keydown.space.prevent="emit('select', customer.id)"
  >
    <div class="card-top">
      <AppAvatar :name="customer.name" />
      <div>
        <div class="card-name">{{ customer.name }}</div>
        <div class="card-sub">{{ customer.company }}</div>
      </div>
    </div>
    <div class="card-meta">
      <AppBadge :status="customer.status" />
      <span class="industry-tag">{{ customer.industry }}</span>
    </div>
    <div class="card-action">詳細を見る →</div>
  </div>
</template>
```

---

## 9. デザインシステム・スタイル定義

既存の `index.html` に定義されている CSS 変数を `src/assets/styles/variables.css` として外出し・標準化します。

```css
:root {
  --bg: #1a1a2e;
  --sidebar-bg: #16213e;
  --header-bg: #0f3460;
  --card-bg: #16213e;
  --card-header-bg: #1f3058;
  --text: #eaeaea;
  --muted: #8a9bb0;
  --accent: #e94560;
  --accent-light: #ff6b81;
  --border: #1f3058;
  --tag-bg: #1f3058;
  --input-bg: #0f1e36;
  --font-family: 'IBM Plex Sans JP', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
```

---

## 10. 今後の拡張性（モダナイゼーションロードマップ）

1. **API連携・非同期処理**:
   - Axios / Fetch API を用いた BFF/バックエンド API クライアント層（`src/api/customerApi.ts`）の導入。
2. **ダッシュボード画面の実装**:
   - Chart.js / ECharts / vue-echarts などを組み込み、商談ステータス別割合や業種別売上 KPI の可視化。
3. **顧客情報の新規登録・編集・削除機能**:
   - フォームバリデーションライブラリ（VeeValidate + Zod 等）を用いた CRUD 機能の実装。
4. **テスト設計**:
   - Vitest によるストア・Composable の単体テスト。
   - Vue Test Utils / Playwright による E2E テストの導入。
