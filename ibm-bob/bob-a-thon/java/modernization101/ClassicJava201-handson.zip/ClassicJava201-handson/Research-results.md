# 調査結果（計画作成時の調査履歴）

[`reverse-engineering-plan-no-docker.md`](reverse-engineering-plan-no-docker.md) の作成時に行った実機確認と Web 検索（`web_fetch`）の経緯・詳細を、ここにまとめる。計画書には結論と出典 URL だけを残している。

- 調査日: 2026-11-19（特記のない限り）
- 本書の内容は「計画作成者が確認した事実」。Bob が成果物に `[spec: URL]` を付けるときは、着手時にその URL を取得し、該当箇所を確認してから付ける。
- Bob はコマンド実行禁止。本書の実行確認は、計画作成者がユーザー指示で行ったもの。

## 1. 実機確認（計画作成者の実行）

### 1.1 `openjdk:7u221-jdk`（計画書 ST1 に対応）
- 実行環境: Rancher Desktop（moby、`rdctl` v1.25.0）、Docker サーバー 29.9.2。
- `docker manifest inspect openjdk:7u221-jdk`: マニフェストリストが取得できた。`linux/amd64`、`linux/arm/v5`、`linux/arm/v7`、`linux/386` を含む。`Dockerfile` は `--platform=linux/amd64` を指定している [src: Dockerfile:1]、[src: Dockerfile:25]。
- `docker pull --platform=linux/amd64 openjdk:7u221-jdk`: 成功。ダイジェストは `sha256:75a05dbcd254fdde1a284c5cc47a8f7d5387cd517cbf9e66d50d45da1c695022`。
- `docker run --rm --platform=linux/amd64 openjdk:7u221-jdk java -version`: `java version "1.7.0_221"`、`OpenJDK Runtime Environment (IcedTea 2.6.18) (7u221-2.6.18-1~deb8u1)`、`OpenJDK 64-Bit Server VM (build 24.221-b02, mixed mode)`。
- 解釈: Docker Hub のタグ情報は `tag_status: inactive` だが、2026-11-19 時点では pull でき、JDK 7u221 として起動する。
- 確認していないこと: 実行環境はこの 1 台のみ。別環境・別日・別のレジストリミラー経由でも pull できるかは未確認。`docker compose up --build` は実行していない。

#### 訂正・補足
- **ダイジェスト**: `docker pull` が表示した `sha256:75a05dbcd254…` は、`docker image inspect` の `.Id` および `RepoDigests` と同じ値。`docker manifest inspect` の `linux/amd64` エントリ（`sha256:d3c81d95b9ce…`）とは別の値。違う理由は未確認（推測で書かない）。`docker image inspect` の `os`、`arch` は空、`size` は 0 と返った。この理由も未確認。
- **Rancher Desktop の起動状態**: `rdctl start --container-engine.name=moby` を実行した（出力は `Status: no changes necessary`）。実行前に VM が起動済みだったかは未確認。最初の `docker version` は `/var/run/docker.sock` に接続できず失敗し、`rdctl start` と 20 秒の待機の後は、`rancher-desktop` コンテキストで接続できた。「すでに起動していた」とは書かない。
- **ホストのアーキテクチャ**: 環境情報ではホストは arm64。`--platform=linux/amd64` で実行したため、エミュレーション下で動いた可能性が高い（確認はしていない）。

### 1.2 稼働中のアプリの観測（ユーザー指示）
- 実施内容: ユーザーが「localhost:8080 で実行できている」と知らせたため、Playwright で `GET /todo/` を 2 回だけ実行した。POST、フォーム操作、`/update`・`/delete` へのアクセスはしていない。
- 観測結果:
  - `GET /todo/` は 302 Moved Temporarily、続く `GET /todo/list` は 200 OK。遷移後の URL は `/todo/list`。
  - ページタイトルは「TODO リスト」。表の列は ID / タイトル / 作成日時 / 完了 / 削除。
  - 行は 6 件（ID 1〜4、125、126）。日本語のタイトル（例: 「研修」）が正しく表示された。ボタン文言は「追加」「完了にする」「未完了に戻す」「削除」。
- 位置づけ: 稼働中の 1 環境の 1 時点の観測。ユーザーの説明では、Rancher Desktop 上の `classicjava201-app-1` を docker compose で起動したもの。読み取りのみの `docker ps` と `docker compose ls` で、次を確認した。
  - 動作中のコンテナ: `classicjava201-app-1`（イメージ `classicjava201-app`、`0.0.0.0:8080->8080`）と `classicjava201-db-1`（`postgres:9.6-alpine`、healthy）。
  - compose の設定ファイルは `/Users/oniak3.ai/modernization/ClassicJava201/docker-compose.yml`（ワークスペース外のディレクトリ）。
  - `diff -rq` で、そのディレクトリと本ワークスペースの `src/`、`web/`、`sql/`、`lib/`、`build.xml`、`Dockerfile`、`docker-compose.yml` に差分がないことを確認した（`*.md`、`.bob`、`docs` は比較対象外）。
  - 未確認: 動作中のイメージがいつ・どのソースからビルドされたか、Tomcat と PostgreSQL の実バージョン、DB の中身の来歴。
- 未観測: 日本語の入力・保存経路、レスポンスヘッダの charset、POST 系、未実装メソッド、エラー系、`list.jsp` 直接アクセス。
- 使い方: ST3（`/todo/` と `/list` の応答）、ST5（日本語の表示）の `Q-xxx` の「暫定の見立て」にだけ書く。確度を「確定」にしない。

### 1.3 実行したコマンドの範囲
計画作成者の実行は、次のみ。
- ST1 の Docker 実行確認（上記 1.1）
- ユーザー指示による Servlet 2.4 仕様の `curl` 保存と `pdftotext` 変換
- 稼働中コンテナの確認（`docker ps`、`docker compose ls`）
- ソースの差分確認（`diff -rq`）

## 2. 公式資料の取得結果（`web_fetch`）

### 2.1 取得できたもの（URL の `https://` は省略したものを含む）

| 資料 | URL | 確認できた内容 |
|---|---|---|
| Tomcat 5.5 ドキュメントトップ | `tomcat.apache.org/tomcat-5.5-doc/` | Servlet 2.4 / JSP 2.0 実装と明記 |
| Tomcat 5.5 HTTP コネクタ | `tomcat.apache.org/tomcat-5.5-doc/config/http.html` | `URIEncoding` 未指定時は ISO-8859-1 |
| Tomcat 5.5 Context / default servlet | `.../config/context.html`、`.../default-servlet.html` | （個別の記述は計画では未使用） |
| Tomcat 5.5 Servlet API Javadoc | `.../servletapi/javax/servlet/http/HttpServlet.html` | 未実装メソッドの応答コードは記載なし（実装依存） |
| Tomcat 5.5 EOL 告知 | `tomcat.apache.org/tomcat-55-eol.html` | 2012-09-30 サポート終了。アーカイブから入手可 |
| Tomcat 5.5 Server 要素 | `https://tomcat.apache.org/tomcat-5.5-doc/config/server.html` | Server 要素の `port` はシャットダウン用ポート |
| Tomcat 5.5.36 配布物 | `archive.apache.org/dist/tomcat/tomcat-5/v5.5.36/bin/` | `apache-tomcat-5.5.36.tar.gz` あり |
| Ant アーカイブ | `archive.apache.org/dist/ant/binaries/` | `apache-ant-1.9.16-bin.tar.gz` あり |
| Apache Ant FAQ | `https://ant.apache.org/faq.html` | 1.9.x の必要 Java は 1.5 以上、1.10.x は 1.8 以上。1.9.16 の公開日は 2021-07-13。1.10.18 は 2026-09-06。1.9.x の EOL 日付の記載はない |
| J2EE 1.4 Javadoc（Oracle） | `HttpServlet`、`HttpServletResponse` | （個別の記述は計画では未使用） |
| JLS SE7 第12章 | `docs.oracle.com/javase/specs/jls/se7/html/jls-12.html` | §12.4.1（初期化時点）、§12.4.2（`ExceptionInInitializerError`） |
| `javac` SE7 | `docs.oracle.com/javase/7/docs/technotes/tools/solaris/javac.html` | `-source 1.4` / `-target 1.4` |
| PostgreSQL 9.6 数値型 | `www.postgresql.org/docs/9.6/datatype-numeric.html` | `serial` は 1〜2147483647。「unsupported version」表示あり |
| PostgreSQL Versioning Policy | `https://www.postgresql.org/support/versioning/` | 各メジャー版は初回リリースから 5 年サポートされ、その後は EOL。9.6 は初回 2016-09-29、最終リリース 2021-11-11、Supported は No。8.4 は最終リリース 2014-07-24 |
| postgres 公式イメージ README | `raw.githubusercontent.com/docker-library/docs/master/postgres/README.md` | `/docker-entrypoint-initdb.d` は空のデータディレクトリのときのみ実行 |
| `openjdk` Docker Hub | `openjdk:7u221-jdk` のタグ情報 | `tag_status` は `inactive`、`last_pushed` は 2019-05-14。リポジトリは非推奨（2022年7月以降は更新なし） |
| PostgreSQL JDBC ダウンロード | `https://jdbc.postgresql.org/download/` | 現行ドライバ 42.7.x は PostgreSQL 8.4 以降に対応と記載（ただしテストは 9.1 以降のみ）、Java 8 以上が必要。Java 7 向けは 42.2.29、Java 6 向けは 42.2.27 |
| JSR-154（Servlet 2.4） | JCP の最終版ページ | PDF 本文は `web_fetch` では取得不可。本書 3 章のとおり `curl` で保存して確認 |
| Docker Compose 仕様（services） | `https://docs.docker.com/reference/compose-file/services/` の `depends_on` | 短い構文は依存先の healthy を待たない。長い構文の `condition: service_healthy` は、依存先の healthcheck が通るまで待つ。現行版の資料であり、Rancher Desktop が使う Compose のバージョンとの差は未確認 |
| Oracle Java SE Support Roadmap | `https://www.oracle.com/java/technologies/java-se-support-roadmap.html` | 表は Java 8 以降のみ。Java 7 の記載はない |

### 2.2 一部のみ・取得できなかったもの

| 資料 | 試した URL | 結果 |
|---|---|---|
| PostgreSQL JDBC 8.4 ドキュメント（Wayback） | `https://web.archive.org/web/2012/https://jdbc.postgresql.org/documentation/84/index.html` | 目次のみ。第 10 章「Using the Driver in a Multithreaded or a Servlet Environment」、第 11 章に「Tomcat setup」がある。互換性の記述は、取得した範囲にない。公式サイト上の `/documentation/84/` は空 |
| Tomcat 5.5.36 の `server.xml`、`conf/web.xml` | `svn.apache.org/repos/asf/tomcat/tc5.5.x/tags/TOMCAT_5_5_36/`、同 `tags/`、`raw.githubusercontent.com/apache/tomcat/TOMCAT_5_5_36/build/conf/server.xml` | いずれも 404 |
| Compose の `restart: on-failure` | 上記 Compose 資料 | 取得出力が途中で切れ、`restart` の節は確認していない |
| JDBC 8.4 と PostgreSQL 9.6 の互換性 | 上記 JDBC 関連 2 資料 | 記述なし |
| Java 7 の EOL | Oracle Java SE Support Roadmap | 記載なし |
| Ant 1.9.x の EOL | Ant FAQ | 日付の記載なし |

### 2.3 取得結果から決まる扱い
- 取得できなかった資料に依存する項目（`server.xml` の `port`、`Dockerfile` の `sed` の効果）は、`[spec:]` を付けず `Q-xxx` にする。
- JDBC 8.4 のドキュメントを `[spec:]` として使う場合は Wayback の URL を付け、備考に「公式サイトでは現在取得不可」と書く。
- 公式資料が取得できず、その項目の影響が「高」の場合のみ、その時点でユーザーに確認する（ユーザー決定）。影響が「中」「低」の場合は `Q-xxx` として記録し、作業を止めない。

## 3. Servlet 2.4 仕様本文の確認結果

- 入手: `https://download.oracle.com/otn-pub/jcp/servlet-2.4-fr-spec-oth-JSpec/servlet-2_4-fr-spec.pdf` を、ユーザーの指示で `curl` により `docs/reference/servlet-2_4-fr-spec.pdf`（1,792,594 バイト、表題「Java Servlet Specification Version 2.4」、`mdls` のページ数は 330）に保存した。読むために `pdftotext -layout` で `docs/reference/servlet-2_4-fr-spec.txt`（13,848 行）に変換した。下表の行番号は、この `.txt` のもの。再配布条件は未確認。
- `web_fetch` では PDF を扱えず取得不可だった。
- 引用するときは、`[spec: 元の URL 節番号]` の形にする。

| 論点 | 仕様の記述（`.txt` の行） | 確認できたこと | 計画上の扱い |
|---|---|---|---|
| `error-page` と例外 | SRV.9.9.2（2640-2675） | `exception-type` は、投げられた例外のクラス階層で照合し、最も近い一致が優先される。一致がなく、例外が `ServletException` の場合は、`getRootCause` で取り出した原因例外で 2 回目の照合を行う。どれにも一致しない場合は、コンテナが 500 を返さなければならない | 仕様上の扱いは確定。`web.xml` の `exception-type` の実値は、着手時にソースで確認すること。`java.lang.Exception` を指定しているなら、`ServletException` 自体が 1 回目の階層照合で一致するため、原因例外による 2 回目の照合は使われない（この記述からの導出）。Tomcat 5.5.36 の実際の動作と、`error.jsp` に表示されるメッセージは `Q-xxx` のまま |
| エラーページへ渡る属性 | SRV.9.9.1（2586-2625） | エラーページが JSP のとき、`javax.servlet.error.exception`（伝播した例外オブジェクト）などの属性が設定される。エラーページでは `setStatus` は無効 | `error.jsp` の挙動の根拠に使える |
| Dispatcher 経由の例外 | SRV.8.5（2350-2356） | `RequestDispatcher` の対象サーブレットが、`ServletException`・`IOException`・ランタイム例外以外を投げた場合は、`ServletException` で包んで原因を設定する | 本アプリで dispatcher を使う箇所があるかは ST2 で確認する |
| welcome files | SRV.9.10（2690-2756） | `welcome-file-list` は、ディレクトリに当たる要求に、順にファイル名を付けて照合する仕組み。一致がない場合は、ディレクトリ一覧や 404 など、コンテナが適切に処理してよいと書かれており、動作は規定されていない | `web.xml` に `welcome-file-list` がない場合の `/todo/` の動作は、仕様では決まらない。Tomcat 側の既定（`conf/web.xml`、取得できていない）に依存する → `Q-xxx`。観測（1.2）: `/todo/` は 302 で `/todo/list` へ |
| URL マッピング | SRV.11.1（3085-3124）、SRV.11.2（3127-3138）、SRV.11.2.1（3141-3148） | 完全一致、最長のパス接頭辞、拡張子の順で照合する。`/` だけの指定が default servlet。コンテナに JSP コンテナがあれば `*.jsp` は暗黙にマップされ、アプリが `*.jsp` を定義していればそちらが優先 | ST3 の URL マッピングの根拠に使える |
| 未実装の HTTP メソッド | `doGet` の説明（9326-9365）、`service` の説明（9557-9578）、`SC_METHOD_NOT_ALLOWED`（10348-10354） | `doGet` を実装していない場合の応答コードの記述は、これらの箇所に見つからなかった。405 が出るのは `SC_METHOD_NOT_ALLOWED` の定数の説明のみ | 仕様では確定できない。Tomcat 5.5.36 の実際の応答とともに `Q-xxx` のまま。Javadoc 側の確認結果（応答コードの記載なし）とも一致する |
| コンテキストパス | SRV.9.1（2365-2373） | Web アプリは、サーバー内の特定のパスにルートされる。コンテナが Web アプリを自動生成する規則を持ってよい | WAR ファイル名（`todo.war`）からコンテキストパス `/todo` が決まる規則は、読み取った範囲に記載なし → `Q-xxx` |

## 4. ソースで行番号を確認できた事項（grep の結果）

Bob は着手時に、行番号を付けて再確認すること。

| 事項 | 場所 |
|---|---|
| PostgreSQL のイメージ `postgres:9.6-alpine` | `docker-compose.yml:3` |
| `init.sql` のマウント | `docker-compose.yml:9` |
| `db` の `healthcheck` | `docker-compose.yml:13` |
| `app` の `build`、`platform: linux/amd64` | `docker-compose.yml:20-21` |
| `ports: 8080:8080` | `docker-compose.yml:22-23` |
| `depends_on`（`condition: service_healthy` は 26 行目） | `docker-compose.yml:24-26` |
| `restart: on-failure` | `docker-compose.yml:27` |
| Tomcat 5.5.36 の取得（builder と runtime） | `Dockerfile:4`、`Dockerfile:28` |
| Ant 1.9.16 の取得、`ant war` | `Dockerfile:10`、`Dockerfile:21` |
| `sed` による `URIEncoding="UTF-8"` の追記 | `Dockerfile:34` |
| WAR を `todo.war` として配置（コンテキストパス `/todo` の出どころ） | `Dockerfile:36` |
| `static` ブロックと `Class.forName("org.postgresql.Driver")` | `TodoDAO.java:19`、`TodoDAO.java:21` |
| `setCharacterEncoding` の直後に `getParameter` | `TodoListServlet.java:29-30`、`TodoUpdateServlet.java:17-18`、`TodoDeleteServlet.java:17-18` |
| `sendRedirect(request.getContextPath() + "/list")` | `TodoListServlet.java:38`、`TodoUpdateServlet.java:29`、`TodoDeleteServlet.java:29` |

- `src/` で `setCharacterEncoding` が現れるのは、上の 3 か所のみ（grep の結果）。どの `doXxx` メソッド内にあるかは未確認。メソッド単位の確認は Bob がソースを読んで行う。

## 5. モダナイゼーション計画（Mac / Windows 版）の実行で確認できたこと

[`modernization-plan-mac-Windows.md`](modernization-plan-mac-Windows.md) を Mac（Apple Silicon）で実行して確認した事実。詳細と反映先は [`modernization-plan-updates.md`](modernization-plan-updates.md) を参照。

- 実行日: 2026-11-20 〜 2026-11-24（途中でセッションが中断され、日をまたいだ）。
- 実行環境: macOS arm64 / Rancher Desktop（Docker 29.9.3-rd、Compose v5.7.0、`docker info` は `linux aarch64`）/ Node v24.22.1・npm 11.19.1。
- 位置づけ: 1 台の Mac、1 回の通し実行の観測。Docker Desktop・Intel Mac・WSL2・Linux は未確認。Node 20.x での `npm run build` も未確認。

### 5.1 計画を通して実行した結果

| 確認項目 | 結果 |
|---|---|
| 3 コンテナ（`migrated/`） | 起動。new-db は `healthy`。ポートは 53080 / 53081 / 53032 |
| new-db のスキーマ | 7 列（`priority` / `due_date` / `updated_at` を追加）とトリガー `set_updated_at`。`down -v` 後の新しいボリュームで `init.sql` が適用された |
| backend の起動 | `Started TodoApplication in 14.99 seconds`（`platform: linux/amd64` のエミュレーション。JVM のクラッシュなし） |
| REST API | GET 200、POST 201、title 空欄 400、不明 id の toggle と DELETE は 404 |
| CORS と Nginx | `Origin: http://127.0.0.1:53080` からの POST が 201、`http://evil.example` は 403。`proxy_set_header Host $http_host;` が効く |
| JUnit | Docker 経由で 9 テスト成功（`BUILD SUCCESS`）。テスト本体は約 5 秒 |
| Playwright E2E | 1 passed。`@playwright/test` 1.65.1。ホストで実行 |
| フロントのビルド | `vite build` 約 0.9 秒、`exit=0`。Vite 5.4.21 / Vue 3.5.45 / Tailwind 3.4.19。`npm warn install-scripts`（esbuild）が出る |
| `migrate.sh` | 旧 DB を `classicjava201base-db-1` と自動検出。旧 3 件（日本語 1 件）が新 3 件に一致し、再実行しても同じ（冪等）。`md5(title)` と日本語 24 バイトが一致。移行後の POST は id=4 で 201。toggle で `updated_at > created_at` |

### 5.2 実行方法（`execute_command`）について確認できたこと

| 確認項目 | 結果 |
|---|---|
| 長時間コマンド | フォアグラウンドでは `timeout_seconds` の最大 270 秒で `TIMED OUT`。初回の `npm install`、`mvn test`（イメージ pull 込み）、`npx playwright install chromium`（約 192 MiB）は 3 つとも完了しなかった |
| `nohup sh -c '…' > log 2>&1 &` | フォアグラウンドから起動しても、コマンド終了とともにジョブが消え、ログも更新されなかった |
| `background: true` | 上記 3 コマンドが完了した。Mac では `docker compose up -d --build` も正常に動いた（Windows では動かなかったという記述は Windows 固有） |
| 長い待機 | 1 コマンド内で 250 秒前後ポーリングすると `CANCELED` になり、`docker compose up` が中断して、コンテナが 1 つも残らなかった |
| 並列起動 | 共有ディレクトリの `mkdir` に依存した 2 つのコマンドが `no such file or directory` で失敗した |

### 5.3 旧アプリ側で確認できたこと

- ルートの `docker compose` では、`app` が `Up` のまま `db` が `Exited (0)` になっていることがあった。この状態では `http://localhost:8080/todo/list` が HTTP 500、`docker compose exec -T db …` が `service "db" is not running`、`migrate.sh` が `old-db / new-db container not found` になった。
- ルートで `docker compose up -d` を実行すると `db` が `healthy` になり、旧アプリは 200 に戻った。
- 未確認: `db` が停止した原因（セッションの終了と関係するかは不明）。

### 5.4 旧画面と新画面の見た目の比較（Playwright / Chromium）

| 確認項目 | 結果 |
|---|---|
| 一致した値 | body のフォント `"MS Gothic", monospace`・13px・余白 20px、`h1` 16px、th の背景 `rgb(204, 204, 204)`、罫線 `1px solid rgb(153, 153, 153)`、td の padding `4px 8px`、テキスト入力 308x21、submit 83x27 |
| 表幅 600px のままの場合（修正前） | 列が 5 → 7 に増え、タイトル列が旧 142px → 新 118px に縮んだ。各列の必要幅（max-content）の合計は 609px で、600px を超えていた |
| 表幅の候補 | 650px → タイトル 129、700px → 139、**720px → 143**（旧 142）、750px → 149 |
| 720px にした後 | 旧 `table:600 ID:35 タイトル:137 作成日時:239 完了:123 削除:65`、新 `table:720 ID:36 タイトル:140 優先度:62 期限:48 作成日時:243 完了:125 削除:66`。全行 36px で、折り返しなし。E2E は 1 passed |
| 折り返しの再現 | **ユーザーの画面（スクリーンショット）では、日本語タイトルと作成日時が折り返した。** この環境の Chromium では、文字幅 91px（「移行テスト日本語」）に対しタイトル列の文字領域が約 100px で、折り返しは再現しなかった |
| 注意 | 当初「日本語タイトルは約 112px 必要」と記録したが、実測ではなかったため訂正した。折り返す幅は、ブラウザの日本語フォントに依存する。絶対値は環境で変わるため、比較は同じブラウザで旧・新を並べて行う |

### 5.5 配信されている最新版の確認（frontend）

- frontend は `dist/` を Nginx にコピーする方式のため、`npm run build` だけでは反映されない。`docker compose up -d --build frontend` でイメージを再ビルドし、frontend だけを再作成できた（backend と DB は再作成されない）。
- 反映の確認は、ソース（`w-[720px]`）、ホストの `dist/` のファイル名と md5、コンテナ内のファイルの md5、Nginx が返す HTML の参照先、配信 CSS の中身（`w-\[720px\]{width:720px}`）を突き合わせた。すべて一致した。

### 5.6 未確認のこと

- Docker Desktop、Intel Mac、WSL2、Linux ネイティブでの実行。
- Node 20.x での `npm run build`。
- `db` の停止の原因（5.3）。
- `migrate.sh` の旧 DB 自動検出が、ルートのディレクトリ名が `classicjava201base` 以外のときにどうなるか（Windows の別名での確認は、計画書の検証結果 #11・#24 にある）。
- ユーザーのブラウザで、表幅 720px の画面に折り返しが残っていないか（私の環境では折り返さない）。
