# リバースエンジニアリング計画（Docker 不使用版） — ClassicJava201 Todo アプリ

> Docker あり版は [`reverse-engineering-plan.md`](reverse-engineering-plan.md)。本書は Bob が Docker を使わず、ソースの読み取りと公式資料の確認だけで進める版（計画作成時の実機確認の結論は 5 章に記載）。2 つの計画書のどちらか一方だけを実施する。

## 1. 概要

### 目的
ソースコードと公式仕様を根拠として現行システムの設計を復元し、モダナイズ（Java / アプリケーションサーバー / ビルド / DB 接続の刷新）に向けた課題・リスク一覧を作成する。実行しないと確定できない挙動は推測で埋めず、「要確認」として一覧に残す。

### スコープ
- **対象**: `src/`、`web/`、`lib/`、`sql/`、`build.xml`、`Dockerfile`、`docker-compose.yml`（いずれも読み取りのみ）
- **成果物**: マークダウンの設計書一式（`docs/reverse-engineering/` 配下に日本語で新規作成）
- **非スコープ**: コードの修正、モダナイズの実施、テストコードの作成、既存資料との差異分析、アプリの実行・ビルド・コンテナ起動（Docker を含む）

### 参照してよいもの・いけないもの
| 区分 | ファイル | 扱い |
|---|---|---|
| 対象ソース | 上記「対象」のファイル | 根拠にする |
| 参照禁止 | `BasicDesign.html`、`AboutThisProject.html`、`.bob/artifacts/*.html` | **開かない**。根拠にもしない。棚卸し表には「対象外（既存資料）」と名前だけ載せる |
| 条件付き | `AGENTS.md`、`.bob/rules-*/AGENTS.md` | 内容が対象ソースで裏付けられる記述だけ根拠に使ってよい。裏付けは必ずソース側の `[src: ...]` を示す。裏付けのない記述は使わない |
| 対象外 | `reverse-engineering-plan.md`、本書、`Research-results.md`、`.DS_Store`、`docs/reference/`（Servlet 2.4 仕様の PDF と、その `pdftotext` 変換結果） | 棚卸し表に載せない。ただし `[spec:]` の確認には使ってよい（下記） |

### 根拠の種類と書式
すべての事実記述に、次のいずれかの根拠を付ける。

| 種類 | 書式 | 使いどころ |
|---|---|---|
| ソース | `[src: ファイル:行]`（例: `[src: src/com/example/todo/dao/TodoDAO.java:19]`）、範囲は `:19-27` | 対象ソース・設定の記述 |
| 公式仕様 | `[spec: URL]` | Java 言語仕様、Servlet / JSP 仕様、Tomcat 5.5・PostgreSQL・JDBC の公式ドキュメント |
| 要確認 | `[Q-001]`（本文）と各文書末尾の「要確認」表 | 上の 2 つで確定できない項目 |

- 行番号は、記述時点のファイルを読み取って確認した値を使う。推測や記憶で書かない。
- `[spec: URL]` は、実際にその URL を取得して該当箇所を確認してから書く。取得できない・該当記述が見つからない場合は `[Q-xxx]` にする。URL だけ貼って内容を確認していない状態は禁止。
- ワークスペースに公式資料の写し（`docs/reference/`）がある場合も、`[spec:]` には元の URL と節番号を書き（例: `[spec: https://download.oracle.com/otn-pub/jcp/servlet-2.4-fr-spec-oth-JSpec/servlet-2_4-fr-spec.pdf SRV.9.9.2]`）、写しの該当箇所を読んで確認してから付ける。
- 公式仕様に記載されていても、製品・バージョン固有の実装挙動（Tomcat 5.5.36 の実際の応答など）は、公式ドキュメントに明記されていなければ「要確認」にする。
- 「要確認」にする判断基準: Tomcat 5.5 / PostgreSQL / JDBC ドライバの実行時の挙動、ネットワークや OS に依存する挙動、ソースに現れない設定値の実効値、公式資料で確認できなかった事項。

### 「要確認」の管理ルール
- ID は `Q-001` から始まる連番で、全文書を通して一意にする。**作業順に採番し、最後に使った番号を各サブタスクの Status 欄に書き残す**（次のサブタスクはその続きから採番する）。
- 各文書の末尾に「要確認」表を置く。列: `ID` / `内容` / `確定できない理由` / `確認方法`（後日の実機確認の手順）/ `暫定の見立て`（任意、根拠付き）。
- サブタスク 10 で全 ID を `README.md` に再掲する。欠番や重複があれば解消する。

### 重大度の表記（サブタスク 9）
「影響 × 確度」を併記する（例: `高・確定`、`中・暫定`）。

| 軸 | 値 | 基準 |
|---|---|---|
| 影響 | 高 | セキュリティ上の問題、またはモダナイズの阻害要因 |
| 影響 | 中 | 保守性・性能への影響 |
| 影響 | 低 | 軽微 |
| 確度 | 確定 | 根拠がソースまたは公式仕様で確認できている |
| 確度 | 暫定 | 実挙動に依存し、「要確認」が残っている |
| 難易度 | 高 | 複数ファイルにまたがる設計変更が必要（例: 名前空間変更、接続方式の刷新） |
| 難易度 | 中 | 1 ファイル内で完結しない修正、または追加の依存が必要 |
| 難易度 | 低 | 1 ファイル内の局所的な修正 |

補足: 「影響」の基準は 2 つの条件のどちらかに該当すれば「高」となる。EOL など多くの項目が「高」に集まる場合は、サブタスク 9 で「影響範囲（波及ファイル数）」を併記し、優先順位をその値で補う。

上記の難易度の基準と補足は、ユーザー承認済み（2026-11-19）。

### 作業の進め方（Bob 向け）
1. 本書と、そのサブタスクの前提成果物（`docs/reverse-engineering/` 内の既存ファイル）を読んでから着手する。
2. サブタスクは 1 つずつ実施する。完了したら、本書の該当サブタスクの Status を `[x] done` に更新し、最後に使った Q 番号と、次のサブタスクへの申し送りを追記して、ユーザーの確認を待つ。確認前に次へ進まない。
3. 作業中に判断に迷う点があっても、立ち止まらず「要確認」として記録して進める。ただし、**計画書の指示と矛盾する**、**計画書にない成果物が必要になる**場合は、ユーザーに質問する。
4. コマンド実行は禁止（`docker`、`ant`、`curl`、`javac` など）。使ってよい操作は、ファイル・シンボルの読み取り、検索（`grep`、`glob`、`FindSymbol`、`FindReferencingSymbols`）、公式資料の取得（`web_fetch`）、成果物ファイルの作成のみ。
5. 図は成果物のマークダウン内で Mermaid を使ってよい（この計画ファイルには含めない）。Mermaid の角括弧内にダブルクォートと丸括弧を入れない。
6. 成果物の本文は日本語。ファイル名、クラス名、URL、コードは原文のまま書く。

### 対象規模
| 区分 | ファイル |
|---|---|
| Java | `Todo`、`TodoDAO`、`TodoListServlet`、`TodoUpdateServlet`、`TodoDeleteServlet`（計 5 ファイル） |
| Web | `list.jsp`、`index.jsp`、`error.jsp`、`WEB-INF/web.xml` |
| DB | `sql/init.sql`（`todos` テーブル 1 つ） |
| ビルド/実行 | `build.xml`、`Dockerfile`（マルチステージ）、`docker-compose.yml`（`app` + `db`） |
| 依存 | `lib/postgresql-8.4-702.jdbc3.jar` のみ |

### 成果物一覧
| ファイル | 内容 | 担当サブタスク |
|---|---|---|
| `docs/reverse-engineering/00-inventory.md` | 資産一覧・技術スタック | 1 |
| `docs/reverse-engineering/01-architecture.md` | 構成・コンポーネント・依存関係 | 2 |
| `docs/reverse-engineering/02-behavior.md` | エンドポイント別の処理フロー・業務ルール | 3 |
| `docs/reverse-engineering/03-data.md` | DB 設計・クラス/テーブル対応 | 4 |
| `docs/reverse-engineering/04-ui-encoding.md` | 画面設計・文字コード | 5 |
| `docs/reverse-engineering/05-error-nfr.md` | エラー処理・非機能の現状 | 6 |
| `docs/reverse-engineering/06-infra-build.md` | ビルド・デプロイ構成（静的な読み取りのみ） | 7 |
| `docs/reverse-engineering/07-modernization-risks.md` | 課題・リスク一覧 | 9 |
| `docs/reverse-engineering/README.md` | 目次・全体サマリ・要確認一覧 | 10 |

注: サブタスク 8 は対象外（スキップ）のため欠番とする。番号は Docker あり版と揃えており、振り直さない。

### 各成果物の共通構成
1. 目的と対象範囲（1〜2 文）
2. 本文（表と Mermaid 図を使い、すべての事実に根拠を付ける）
3. 末尾に「要確認」表（なければ「なし」と書く）

---

## 2. サブタスク

### サブタスク 1: 資産棚卸しと技術スタックの確定
- **Intent**: 調査対象の全体像と、設定ファイルに宣言されているバージョン・設定値を確定し、以降の土台にする。
- **Expected Outcomes**: ファイル一覧、各ファイルの役割、技術スタック表（言語レベル、JDK、Tomcat、Servlet API、Ant、PostgreSQL、JDBC）が根拠付きで揃う。
- **Todo List**:
  1. ディレクトリ配下のファイルを列挙し、役割を 1 行で記載する。参照禁止・対象外のファイルは、上記の区分どおり名前と区分だけを載せる（内容は読まない）。
  2. バージョン情報を設定ファイルから抽出する（`build.xml` の `source/target`、`Dockerfile` のベースイメージ・Tomcat・Ant、`docker-compose.yml` の PostgreSQL、`web.xml` の Servlet 版数と XML Schema (XSD)、JDBC jar 名）。
  3. 宣言上のバージョンが食い違って見える箇所を明示する。例: コンパイルターゲット 1.4 と JDK 7 の組み合わせ、Servlet 2.4 と Tomcat 5.5、JDBC3 ドライバ 8.4 と PostgreSQL 9.6。`javac` の `-source` / `-target` 1.4 と Tomcat 5.5 の Servlet 2.4 実装は 5.2 の結論を使い `[spec: URL]` を付ける。JDBC 8.4 と PostgreSQL 9.6 の互換性は 5.4 のとおり `Q-xxx` にする。
  4. Tomcat 5.5.36 / Ant 1.9.16 の配布物は「5.2 公式資料で確認済み」の結論を使う。`openjdk:7u221-jdk` は「5.1 実機確認済み」の結論を使う（Bob は再実行しない）。
  5. `00-inventory.md` を作成する。
- **実機確認済みの結論**: `openjdk:7u221-jdk` は 2026-11-19 に pull でき JDK 1.7.0_221 として起動した（確認済み。経緯は `Research-results.md` 1.1）。タグは Docker Hub 上 `inactive`。成果物には事実として書かず、関連する `[Q-xxx]` の「暫定の見立て」欄にだけ「2026-11-19 に計画作成者が 1 回実行して pull と起動を確認（出典: `reverse-engineering-plan-no-docker.md` 5.1）」と書く。確度は「暫定」。別環境での再現と `docker compose up --build` の成否は `Q-xxx`。
- **Relevant Context**: [`build.xml`](build.xml)、[`Dockerfile`](Dockerfile)、[`docker-compose.yml`](docker-compose.yml)、[`web/WEB-INF/web.xml`](web/WEB-INF/web.xml)、`lib/`
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-002`
- **次サブタスクへの申し送り**: サブタスク 2 は `Q-003` から採番してください。資産棚卸しおよび技術スタック表は `docs/reverse-engineering/00-inventory.md` に作成済みです。

### サブタスク 2: アーキテクチャとコンポーネント依存の復元
- **Intent**: レイヤー構成とクラス間・ファイル間の依存を、コードの参照関係から復元する。
- **Expected Outcomes**: コンポーネント図、パッケージ構成、依存方向（Servlet → DAO → DB、Servlet → JSP）が図と表で示される。
- **Todo List**:
  1. 各 Servlet が呼び出す DAO メソッド、forward / redirect 先を一覧化する。
  2. `FindReferencingSymbols` で `TodoDAO`、`Todo` の Java 内の利用箇所を確認する。**JSP は対象外となる可能性が高いため、`grep` で `web/` 配下も別途検索して補う**（`list.jsp` が `Todo` を import している点を含む）。
  3. JSP と Java の結合点（`request` 属性 `todos`、`Todo` クラスの import）を特定する。
  4. Service 層の有無、共通基底クラス・共通ユーティリティ・`Filter`・`Listener` の有無を確認する。
  5. 各クラスを `HttpServlet` から継承している点、`TodoDAO` を毎回 `new` している点（状態を持たないか）を記述する。
  6. `01-architecture.md` に記載する。
- **Relevant Context**: [`TodoDAO.java`](src/com/example/todo/dao/TodoDAO.java)、[`Todo.java`](src/com/example/todo/model/Todo.java)、`src/com/example/todo/servlet/` の 3 ファイル、[`list.jsp`](web/list.jsp)
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-003`
- **次サブタスクへの申し送り**: サブタスク 3 は `Q-004` から採番してください。アーキテクチャおよび依存関係は `docs/reverse-engineering/01-architecture.md` に作成済みです。

### サブタスク 3: 振る舞い（機能・処理フロー・業務ルール）の復元
- **Intent**: URL ごとの入力・処理・出力・副作用を、ソースと公式仕様から読み取れる範囲で正確に記述する。
- **Expected Outcomes**: エンドポイント別の仕様表、シーケンス図（一覧表示、追加、完了トグル、削除）、業務ルール一覧（暗黙の仕様を含む）が揃う。実行しないと確定しない項目は「要確認」として明示される。
- **Todo List**:
  1. `web.xml` の URL マッピングと Servlet クラスの対応を表にする。
  2. 各エンドポイントについて、HTTP メソッド、パラメータ、バリデーション、DAO 呼び出し、リダイレクト先を記述する。
  3. 暗黙の仕様を洗い出す。例: タイトルは `trim()` 後に空なら無視、`id` が `null` なら何もせずリダイレクト、完了トグルは SQL の `NOT done`、`index.jsp` のリダイレクト。
  4. **`web.xml` に `welcome-file-list` がない**ことを記述する。`/todo/` の動作は仕様で決まらず Tomcat の既定に依存するため `Q-xxx` にする。暫定の見立て: 稼働中アプリでは 302 で `/todo/list` へ（5.1、5.4）。
  5. 各 Servlet が実装していない HTTP メソッド（`/update`・`/delete` への GET など）は、「`doGet` を実装していない」ことをソースで示す。応答コードは仕様・Javadoc に記載がないため `Q-xxx` にする（5.4）。
  6. `list.jsp` を `/list.jsp` に直接アクセスした場合、`request` 属性 `todos` が `null` のまま `todos.iterator()` が呼ばれる点をソースで示す。実際の画面表示は「要確認」にする。
  7. `POST /list` で `title` を `trim()` して登録するが、`request.setCharacterEncoding` が `getParameter` より前に呼ばれていること、`doGet` では呼ばれていないことを記述する。
  8. `02-behavior.md` に記載する。
- **Relevant Context**: [`web.xml`](web/WEB-INF/web.xml)、`TodoListServlet`、`TodoUpdateServlet`、`TodoDeleteServlet`、[`index.jsp`](web/index.jsp)、[`list.jsp`](web/list.jsp)
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-007`
- **次サブタスクへの申し送り**: サブタスク 4 は `Q-008` から採番してください。振る舞い・処理フロー・業務ルール仕様は `docs/reverse-engineering/02-behavior.md` に作成済みです。

### サブタスク 4: データ設計の復元
- **Intent**: テーブル定義とアプリ側のデータ型・SQL の対応を明確にする。
- **Expected Outcomes**: ER 図（1 テーブル）、カラム定義、クラスフィールドとのマッピング、DAO の SQL 一覧が揃う。
- **Todo List**:
  1. `init.sql` からカラム・制約・デフォルト値を抽出する。
  2. `Todo` のフィールドと `ResultSet` の取得メソッド（`getInt`、`getString`、`getBoolean`、`getTimestamp`）の対応を表にする。
  3. DAO の 4 メソッドの SQL とパラメータバインドを一覧化する。
  4. 制約とアプリ側の整合を確認する。`VARCHAR(200)` に対するアプリ側の長さチェックの有無、インデックスの有無、`SERIAL` と Java `int` の範囲（5.2 の結論を使い `[spec: URL]` を付ける）。長さ超過時の実挙動は `Q-xxx` にする。
  5. `init.sql` が初回起動時のみ実行される点を、`docker-compose.yml` のマウント設定（`/docker-entrypoint-initdb.d`）から記述する。実行条件は 5.2 の結論を使い `[spec: URL]` を付ける。
  6. 接続方式（`DriverManager`、ハードコード値、`static` ブロックでのドライバロード）を記録し、`03-data.md` に記載する。
- **Relevant Context**: [`sql/init.sql`](sql/init.sql)、`TodoDAO`、`Todo`
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-009`
- **次サブタスクへの申し送り**: サブタスク 5 は `Q-010` から採番してください。データ設計仕様は `docs/reverse-engineering/03-data.md` に作成済みです。

### サブタスク 5: 画面設計と文字コード処理の復元
- **Intent**: ユーザーに見える挙動と、日本語を正しく扱うための仕組みを記録する。
- **Expected Outcomes**: 画面一覧、`list.jsp` の表示項目・フォーム・ボタン文言、完了時の表示切替、文字コード設定の全経路が整理される。
- **Todo List**:
  1. `list.jsp` の表示項目、フォーム（action、method、hidden 項目）、条件分岐表示を表にする。
  2. `index.jsp`、`error.jsp` の役割を記述する。
  3. 文字コードの設定箇所を網羅する（`javac -encoding`、JSP `pageEncoding` / `contentType`、`setCharacterEncoding`、Dockerfile の `server.xml` への `URIEncoding` 注入）。
  4. `Dockerfile` の `sed` コマンドが、`server.xml` の `port="8080"` を含む行にだけ作用する点を記述する。同梱 `server.xml` に該当文字列があるかは取得不可のため `Q-xxx` にする（5.4）。`URIEncoding` 未指定時の既定は 5.2 の結論を使う。
  5. HTML 仕様（HTML 4.01 Transitional、IE 互換 meta、フォント指定）を記録する。
  6. 日本語入力時の実挙動は「要確認」にし、`04-ui-encoding.md` に記載する。
- **Relevant Context**: [`list.jsp`](web/list.jsp)、[`index.jsp`](web/index.jsp)、[`error.jsp`](web/error.jsp)、`Dockerfile` の `server.xml` 書き換え行
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-011`
- **次サブタスクへの申し送り**: サブタスク 6 は `Q-012` から採番してください。画面設計および文字コード処理仕様は `docs/reverse-engineering/04-ui-encoding.md` に作成済みです。

### サブタスク 6: エラー処理と非機能の現状把握
- **Intent**: 例外がどこで発生し、どこへ伝播するかをコードから追い、非機能面の現状（セキュリティ、性能、運用）を記録する。
- **Expected Outcomes**: 例外別の流れ（発生箇所 → 変換 → `web.xml` の `error-page` 設定）の表と、非機能観点（認証、入力検証、XSS、CSRF、接続管理、ログ、設定管理）の現状チェックリストが揃う。
- **Todo List**:
  1. 例外ごとの流れをコード上で追う（`SQLException`、`NumberFormatException`、`ClassNotFoundException`（`static` ブロック）、未捕捉例外 → `error-page`）。
  2. `finally` 内の空 `catch` による握り潰し箇所を列挙する。
  3. `error.jsp` が `exception.getMessage()` を出力する点を記述する。`error-page` の照合規則は 5.3 の結論（SRV.9.9.2）を使い、`web.xml` の実値はソースで確認する。実際に表示されるメッセージと Tomcat 5.5.36 の動作は `Q-xxx` にする。
  4. `TodoDAO` の `static` ブロックが実行される時点は、5.2 の JLS §12.4.1・§12.4.2 の結論を使い `[spec: URL]` を付ける。Tomcat 起動時に実行されるかどうかは `Q-xxx` にする。
  5. 非機能観点をソースベースで記録する: 認証・認可、CSRF トークン、出力エスケープ（`list.jsp` の `<%= %>`）、接続プール、ログ出力、設定の外部化の有無。
  6. `05-error-nfr.md` に記載する。
- **Relevant Context**: `TodoDAO` の `static` ブロックと各 `finally`、各 Servlet の `catch`、[`error.jsp`](web/error.jsp)、`web.xml` の `error-page`
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-013`
- **次サブタスクへの申し送り**: サブタスク 7 は `Q-014` から採番してください。エラー処理および非機能要件の現状は `docs/reverse-engineering/05-error-nfr.md` に作成済みです。

### サブタスク 7: ビルド・デプロイ構成の復元（静的読み取りのみ）
- **Intent**: ソースから WAR を作りコンテナで動かすまでの手順を、設定ファイルの記述だけから復元する。実行はしない。
- **Expected Outcomes**: ビルドフロー、コンテナ構成、ネットワーク、永続化、起動順序、ローカル実行不可の理由がソース根拠付きで記録される。実際に成功するかどうかは「要確認」として明記される。
- **Todo List**:
  1. Ant ターゲット（`init`、`compile`、`war`、`clean`）と classpath 構成を記述する。
  2. Docker の builder / runtime 各ステージの処理と、WAR のコピー経路を記述する。
  3. `docker-compose.yml` の `db` ヘルスチェック、`depends_on`、ボリューム、`init.sql` マウント、`app` の `restart: on-failure` を整理する。`app` 側にヘルスチェックや待機がなく、`db` の起動完了待ちを `depends_on` の `service_healthy` に頼る点を記述する（`depends_on` の挙動は 5.2 の結論。`restart: on-failure` は 5.4）。
  4. 外部ダウンロード（archive.apache.org）への依存と、`linux/amd64` 固定の影響を、記述上わかる範囲で記録する。
  5. 「`docker compose up --build` が成功するか」「WAR が配備されて `/todo/` で応答するか」は `Q-xxx` とする。暫定の見立て: 稼働中アプリは `/todo/` で応答（5.1）。ベースイメージ・配布物の入手可否は 5.1、5.2 の結論を使う。
  6. `build.xml` の `tomcat.lib` がコンテナ内パスでローカル実行できない理由を、ソース根拠付きで記録する。
  7. `06-infra-build.md` に記載する。
- **Relevant Context**: [`build.xml`](build.xml)、[`Dockerfile`](Dockerfile)、[`docker-compose.yml`](docker-compose.yml)
- **前提サブタスク**: 1
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-015`
- **次サブタスクへの申し送り**: サブタスク 8 はスキップです。サブタスク 9 は `Q-016` から採番してください。ビルド・デプロイ構成仕様は `docs/reverse-engineering/06-infra-build.md` に作成済みです。

### サブタスク 8: スキップ（対象外）
- **Intent**: 既存設計資料との突き合わせ。ユーザー指示により実施しない。既存資料は無視する。
- **Status**: `[-] skipped`

### サブタスク 9: モダナイズ課題・リスク一覧の作成
- **Intent**: 復元した設計に基づき、移行時に影響する課題とリスクを、根拠・影響範囲・優先度付きで整理する。
- **Expected Outcomes**: カテゴリ別（セキュリティ、互換性、ビルド、実行基盤、コード品質、データ、テスト）の課題表。各項目に根拠、影響範囲、リスク、対応方針の候補が付く。実挙動に依存する課題には対応する `Q-xxx` と「暫定」が付く。
- **Todo List**:
  1. サブタスク 1〜7 の結果から課題を抽出する。候補: ハードコードされた接続情報、未エスケープ出力（XSS）、CSRF 対策なし、EOL コンポーネント、Java 1.4 構文（raw type）、スクリプトレット JSP、`javax.servlet` から `jakarta.servlet` への名前空間変更、`web.xml` 2.4 XML Schema (XSD)、JDBC3 ドライバ、`DriverManager` 直接接続、空 `catch`、自動テストなし、`ant` のローカル実行不可。候補にない課題も根拠があれば追加する。
  2. 各課題に根拠（`[src: ...]` または `[spec: ...]`）を付ける。EOL の根拠は 5.2 の結論を使う（PostgreSQL 9.6、Tomcat 5.5 は `[spec: URL]`。Java 7、Ant 1.9.x は 5.4 のとおり `Q-xxx`）。
  3. 影響範囲（変更が波及するファイル）と、先に解決すべき依存関係を整理する。
  4. 重大度を「影響 × 確度」で付与し、対応の難易度（高・中・低）も付ける。基準は文書冒頭に表で明記する。
  5. 移行前後で振る舞いを比較するための受け入れ確認項目を、サブタスク 3 の業務ルールから導出して添付する。実行して確かめる必要のある項目（サブタスク 3〜7 の「要確認」）は、「移行前に実機で確認すべき項目」として別表にまとめる。
  6. `07-modernization-risks.md` に記載する。
- **Relevant Context**: サブタスク 1〜7 の成果物
- **前提サブタスク**: 1〜7
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-017`
- **次サブタスクへの申し送り**: サブタスク 10 は `Q-001`〜`Q-017` の全要確認項目を集約し、クロスチェックと README.md の作成を行ってください。モダナイズ課題・リスク一覧は `docs/reverse-engineering/07-modernization-risks.md` に作成済みです。

### サブタスク 10: 成果物の統合とレビュー
- **Intent**: 全成果物の整合性を確認し、読み手が迷わない入口を用意する。
- **Expected Outcomes**: `README.md`（目次、システム要約、用語集、要確認一覧）と、成果物間の用語・数値の整合が取れた状態。
- **Todo List**:
  1. 全成果物のクロスチェックを行い、用語・URL・クラス名・バージョンの表記ゆれを統一する。
  2. 全ファイルの `[src: ファイル:行]` を抜き取りで再確認し、行番号のずれがないかを確認する（最低、各文書 3 件）。
  3. 各成果物の「要確認」表の ID を集約し、欠番・重複を解消して `README.md` に再掲する。各項目に確認方法を残す。
  4. `README.md` を作成する（目次、システム要約、課題トップ項目への導線、要確認一覧）。
  5. ユーザーによる最終レビューを受け、指摘を反映する。
- **Relevant Context**: `docs/reverse-engineering/` 全体
- **Status**: `[x] done` (2026-11-19)
- **最終採番**: `Q-017`（全 17 件集約完了）
- **備考**: 全成果物の統合 README.md を作成し、全サブタスク（ST-01〜ST-07, ST-09, ST-10）が完了しました。

---

## 3. 全体の依存関係

- サブタスク 1 を最初に実施する（以降すべての前提）。
- サブタスク 2〜7 は 1 の後、任意の順で実施できる（推奨順は番号順）。Docker あり版と違い、実行検証が無いため 7 の前提は 1 だけ。
- サブタスク 8 はスキップ。
- サブタスク 9 は 1〜7 の完了後に実施する。
- サブタスク 10 は最後に実施する。

## 4. Docker あり版との違い

| 項目 | Docker あり版 | 本書（Docker 不使用版） |
|---|---|---|
| 根拠の種類 | ソース / 実行確認 / 未検証 | ソース / 公式仕様 / 要確認 |
| サブタスク 7 | 構成の復元 + 実行検証（V1〜V12） | 構成の静的読み取りのみ |
| 実挙動に依存する項目 | 実行して確定 | 「要確認」のまま残す |
| 課題一覧の重大度 | 実行結果で確定 | 実挙動依存の項目は「暫定」 |
| サブタスク 7 の前提 | サブタスク 3〜6 | サブタスク 1 |
| コマンド実行 | `docker compose`、`curl` など | 禁止 |

## 5. 調査済みの結論

計画作成時（2026-11-19）に、実機確認と公式資料の取得を済ませた。詳細・経緯・未確認事項は [`Research-results.md`](Research-results.md) に記載している。経緯の確認が必要なときだけ読んでよい（成果物には書かない）。

- Bob は、下表の「結論」を使ってよい。理由は「確認済み」または出典 URL で足りる。経緯は成果物に書かない。
- `[spec: URL]` を付けるときは、着手時にその URL を取得して該当箇所を確認する。取得できない場合は `[Q-xxx]` にする。
- 実機確認の結果は、根拠の種類を増やさず、関連する `[Q-xxx]` の「暫定の見立て」欄にだけ書く（ユーザー決定）。確度は「暫定」とする。
- 影響が「高」の項目の公式資料が取得できない場合のみ、その時点でユーザーに確認する。それ以外は `Q-xxx` で進める（ユーザー決定）。

### 5.1 実機確認済み

| 項目 | 結論 | 理由 | 使う ST |
|---|---|---|---|
| `openjdk:7u221-jdk` の入手と起動 | 2026-11-19 に 1 台の環境で pull でき、JDK 1.7.0_221 として起動した。タグは Docker Hub 上 `inactive`。別環境での再現は未確認 → `Q-xxx` | 確認済み（`Research-results.md` 1.1） | ST1 |
| 稼働中アプリの `/todo/` と `/todo/list` | `/todo/` は 302 で `/todo/list` へ、`/todo/list` は 200 で 6 件表示、日本語は正しく表示された | 確認済み（同 1.2）。ソースは稼働中の compose 元と差分なし | ST3、ST5 |

- 未観測のため `Q-xxx` のままにするもの: 日本語の入力・保存経路、レスポンスヘッダの charset、POST 系、未実装メソッド、エラー系、`list.jsp` 直接アクセス、Tomcat と PostgreSQL の実バージョン。

### 5.2 公式資料で確認済み

| 項目 | 結論 | 出典（`https://` 省略） | 使う ST |
|---|---|---|---|
| Tomcat 5.5 の実装仕様 | Servlet 2.4 / JSP 2.0 | `tomcat.apache.org/tomcat-5.5-doc/` | ST1 |
| Tomcat 5.5 の EOL | 2012-09-30 にサポート終了。配布物はアーカイブから入手可 | `tomcat.apache.org/tomcat-55-eol.html` | ST1、ST9 |
| Tomcat 5.5.36 配布物 | `apache-tomcat-5.5.36.tar.gz` あり | `archive.apache.org/dist/tomcat/tomcat-5/v5.5.36/bin/` | ST1 |
| Ant 1.9.16 配布物 | `apache-ant-1.9.16-bin.tar.gz` あり | `archive.apache.org/dist/ant/binaries/` | ST1 |
| Ant 1.9.x の必要 Java | 1.5 以上（1.10.x は 1.8 以上）。1.9.16 の公開日は 2021-07-13 | `ant.apache.org/faq.html` | ST1、ST9 |
| `URIEncoding` の既定 | 未指定時は ISO-8859-1 | `tomcat.apache.org/tomcat-5.5-doc/config/http.html` | ST5 |
| Server 要素の `port` | シャットダウン用ポート | `tomcat.apache.org/tomcat-5.5-doc/config/server.html` | ST5 |
| `javac` の `-source` / `-target` 1.4 | JDK 7 の `javac` のドキュメントに 1.4 の記載あり（着手時に該当箇所を再確認する） | `docs.oracle.com/javase/7/docs/technotes/tools/solaris/javac.html` | ST1 |
| クラスの初期化時点、初期化失敗時 | §12.4.1（初期化時点）、§12.4.2（`ExceptionInInitializerError`） | `docs.oracle.com/javase/specs/jls/se7/html/jls-12.html` | ST6 |
| PostgreSQL `serial` の範囲 | 1〜2147483647 | `www.postgresql.org/docs/9.6/datatype-numeric.html` | ST4 |
| PostgreSQL 9.6 の EOL | 最終リリース 2021-11-11、Supported は No | `www.postgresql.org/support/versioning/` | ST1、ST9 |
| `init.sql` の実行条件 | `/docker-entrypoint-initdb.d` は空のデータディレクトリのときのみ実行 | `raw.githubusercontent.com/docker-library/docs/master/postgres/README.md` | ST4 |
| Compose の `depends_on` | `condition: service_healthy` は依存先の healthcheck 成功まで待つ。短い構文は待たない。現行版の資料で、利用環境の Compose との差は未確認 | `docs.docker.com/reference/compose-file/services/` | ST7 |
| 移行先 JDBC ドライバ候補 | 現行 42.7.x は PostgreSQL 8.4 以降対応と記載、Java 8 以上が必要。Java 7 向けは 42.2.29 | `jdbc.postgresql.org/download/` | ST9 |

### 5.3 Servlet 2.4 仕様で確認済み

- 原本は `docs/reference/servlet-2_4-fr-spec.pdf`（`.txt` は変換結果）。`[spec:]` には元の URL と節番号を書く。元 URL: `https://download.oracle.com/otn-pub/jcp/servlet-2.4-fr-spec-oth-JSpec/servlet-2_4-fr-spec.pdf`
- 行番号は `servlet-2_4-fr-spec.txt` のもの。

| 論点 | 結論 | 節（`.txt` の行） | 使う ST |
|---|---|---|---|
| `error-page` と例外 | `exception-type` はクラス階層で照合する。一致なしで `ServletException` なら `getRootCause` の原因例外で再照合する。どれにも一致しなければ 500。`web.xml` の実値は着手時にソースで確認し、`java.lang.Exception` なら 1 回目で一致する（導出） | SRV.9.9.2（2640-2675） | ST6 |
| エラーページの属性 | JSP のエラーページには `javax.servlet.error.exception` などが設定される。エラーページでは `setStatus` は無効 | SRV.9.9.1（2586-2625） | ST6 |
| Dispatcher 経由の例外 | `ServletException`、`IOException`、ランタイム例外以外は `ServletException` で包まれる | SRV.8.5（2350-2356） | ST2 |
| URL マッピング | 完全一致、最長のパス接頭辞、拡張子の順。`/` が default servlet。`*.jsp` は JSP コンテナが暗黙にマップし、アプリの定義が優先 | SRV.11.1〜11.2.1（3085-3148） | ST3 |

### 5.4 仕様・資料で確定できないもの（`Q-xxx` にする）

| 項目 | 状況 |
|---|---|
| `welcome-file-list` がない場合の `/todo/` の動作 | 仕様は規定なし（SRV.9.10、2690-2756）。Tomcat の `conf/web.xml` は取得不可。稼働中アプリでは 302 で `/todo/list` へ（暫定の見立て） |
| 未実装メソッド（`/update`、`/delete` への GET）の応答コード | 仕様・Javadoc とも記載なし |
| WAR 名 `todo.war` からコンテキストパス `/todo` が決まる規則 | 仕様に記載なし（SRV.9.1、2365-2373）。稼働中アプリは `/todo/` で応答（暫定の見立て） |
| `Dockerfile` の `sed` が `server.xml` に効くか | Tomcat 5.5.36 の `server.xml` が取得不可（404） |
| JDBC 8.4 と PostgreSQL 9.6 の互換性 | 公式資料に記載なし（Wayback は目次のみ） |
| Java 7 の EOL | Oracle の公式表に Java 7 の記載なし |
| Ant 1.9.x の EOL | 公式 FAQ に EOL 日付の記載なし |
| `restart: on-failure` の動作 | 資料の該当節を未確認。着手時に取得し、確認できなければ `Q-xxx` |

### 5.5 ソースの行番号（着手時に再確認する）

| 事項 | 場所 |
|---|---|
| `postgres:9.6-alpine` | `docker-compose.yml:3` |
| `init.sql` のマウント | `docker-compose.yml:9` |
| `db` の `healthcheck` | `docker-compose.yml:13` |
| `app` の `build`、`platform: linux/amd64` | `docker-compose.yml:20-21` |
| `ports: 8080:8080` | `docker-compose.yml:22-23` |
| `depends_on`（`service_healthy` は 26 行目） | `docker-compose.yml:24-26` |
| `restart: on-failure` | `docker-compose.yml:27` |
| Tomcat 5.5.36 の取得 | `Dockerfile:4`、`Dockerfile:28` |
| Ant 1.9.16 の取得、`ant war` | `Dockerfile:10`、`Dockerfile:21` |
| `sed` による `URIEncoding="UTF-8"` の追記 | `Dockerfile:34` |
| WAR を `todo.war` として配置 | `Dockerfile:36` |
| `static` ブロックと `Class.forName` | `TodoDAO.java:19`、`TodoDAO.java:21` |
| `setCharacterEncoding` の直後に `getParameter` | `TodoListServlet.java:29-30`、`TodoUpdateServlet.java:17-18`、`TodoDeleteServlet.java:17-18` |
| `sendRedirect(request.getContextPath() + "/list")` | `TodoListServlet.java:38`、`TodoUpdateServlet.java:29`、`TodoDeleteServlet.java:29` |

- `setCharacterEncoding` は 3 サーブレットともすべて `doPost` の先頭にあり、`doGet` には存在しないことをソースで確認済み。

## 6. 決定事項（ユーザー回答 2026-11-19）

1. 根拠の種類は増やさない。実機確認は、関連する `[Q-xxx]` の「暫定の見立て」欄にだけ書く。
2. Servlet 2.4 仕様の PDF は、ワークスペースに保存して読む（実施済み）。
3. ST9 の EOL 根拠のうち、Java 7 と Ant 1.9.x は公式資料で確認できなかったため、`Q-xxx` で進める。
4. 調査履歴は `Research-results.md` に分け、計画書には結論と出典だけを書く。
