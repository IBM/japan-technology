# AIエージェントで実践するレガシーJavaアプリのリバースエンジニアリング ハンズオン

## 1. ハンズオンの概要と目的

### 1.1 背景と課題
企業の基幹系・業務システムには、Java 1.4 や Servlet 2.4、Tomcat 5.5 といったEOL（サポート終了）を迎えた古い技術スタックで稼働し続けている「レガシーシステム」が数多く存在します。設計書が散逸・陳腐化している場合、安全なモダナイズ（Java 17/21 + Jakarta EE、クラウド移行）に着手する前に、**ソースコードと実行環境のみを根拠とした正確なリバースエンジニアリング**が不可欠となります。

### 1.2 本ハンズオンのゴール
本ハンズオンでは、AI開発アシスタント「**Bob**」を活用し、レガシーなTODOアプリケーション（ClassicJava201）の設計書一式（資産一覧、アーキテクチャ、振る舞い、データ設計、UI/文字コード、エラー・非機能、ビルド構成、モダナイズリスク）を**約30分で段階的に復元・ドキュメント化する手法**を学びます。

### 1.3 前提環境と準備
- **対象リポジトリ**: `ClassicJava201base`
- **利用ツール**: IBM Bob (Plan モード / Agent モード)
- **基準ドキュメント**:
  - 計画書: `reverse-engineering-plan-no-docker.md`
  - タスクカード: `reverse-engineering-task-cards.md`

---

## 2. リバースエンジニアリングの基本原則

Bobを用いたリバースエンジニアリングでは、**ハルシネーション（推測や思い込み）を排除し、再現性と客観性の高い設計書を作成する**ために以下のルールを徹底します。

### 2.1 根拠記述ルール
作成するすべての設計書において、記述内容には必ず以下の根拠タグを明記します。

| 根拠種別 | 記法 | 用途・具体例 |
|---|---|---|
| **ソースコード** | `[src: ファイルパス:行番号]` | ソースコードや設定ファイルに基づく事実（例: `[src: src/com/example/todo/dao/TodoDAO.java:19]`） |
| **公式仕様** | `[spec: URL 節番号]` | Servlet仕様や言語仕様に基づく仕様（例: `[spec: Servlet 2.4 Specification SRV.9.9.2]`） |
| **未確定・要確認** | `[Q-xxx]` | 実機実行や動的環境に依存し、静的コード読み取りだけでは確定できない事項（例: `[Q-001]`） |

### 2.2 計画駆動アプローチ（Plan & Task Card）
1つの大きな指示で一括生成させるのではなく、**「タスクカード」単位で1タスクずつ順次進め、人間が成果物をレビュー・承認してから次のタスクへ進める**ことで、高品質なドキュメント群を構築します。

---

## 3. 実績作業時間サマリ

Bob が実際に行ったリバースエンジニアリング（全9タスク完了・全8ドキュメント生成）の作業時間は以下の通りです。合計 **約32分30秒** で全工程が完了します。

| タスクID | タスク名 | 実績所要時間 | 生成される成果物 | 採番 Q 番号 |
|---|---|---|---|---|
| **ST-01** | 資産棚卸しと技術スタックの確定 | **6分25秒** | `docs/reverse-engineering/00-inventory.md` | Q-001, Q-002 |
| **ST-02** | アーキテクチャとコンポーネント依存の復元 | **3分49秒** | `docs/reverse-engineering/01-architecture.md` | Q-003 |
| **ST-03** | 振る舞い（機能・処理フロー・業務ルール）の復元 | **4分35秒** | `docs/reverse-engineering/02-behavior.md` | Q-004 〜 Q-007 |
| **ST-04** | データ設計の復元 | **3分35秒** | `docs/reverse-engineering/03-data.md` | Q-008, Q-009 |
| **ST-05** | 画面設計と文字コード処理の復元 | **3分40秒** | `docs/reverse-engineering/04-ui-encoding.md` | Q-010, Q-011 |
| **ST-06** | エラー処理と非機能の現状把握 | **4分02秒** | `docs/reverse-engineering/05-error-nfr.md` | Q-012, Q-013 |
| **ST-07** | ビルド・デプロイ構成の復元（静的解析） | **4分24秒** | `docs/reverse-engineering/06-infra-build.md` | Q-014, Q-015 |
| **ST-08** | （既存設計資料との突合せ） | *スキップ* | — | — |
| **ST-09** | モダナイズ課題・リスク一覧の作成 | **4分28秒** | `docs/reverse-engineering/07-modernization-risks.md` | Q-016, Q-017 |
| **ST-10** | 成果物の統合とレビュー・README作成 | **4分29秒** | `docs/reverse-engineering/README.md` | 全17件集約 |
| **合計** | **全工程完了** | **32分30秒** | **設計書一式（全8文書）** | **Q-001〜Q-017** |

---

## 4. ハンズオン実行ステップ

各ステップのプロンプトを Bob に入力してリバースエンジニアリングを進めてください。

```mermaid
graph TD
    ST1[Step 1: ST-01 資産棚卸し・技術スタック] --> ST2[Step 2: ST-02 アーキテクチャ・依存関係]
    ST1 --> ST3[Step 3: ST-03 振る舞い・業務ルール]
    ST1 --> ST4[Step 4: ST-04 データ設計]
    ST1 --> ST5[Step 5: ST-05 画面設計・文字コード]
    ST1 --> ST6[Step 6: ST-06 エラー処理・非機能]
    ST1 --> ST7[Step 7: ST-07 ビルド・デプロイ構成]
    
    ST2 --> ST9[Step 8: ST-09 モダナイズ課題・リスク]
    ST3 --> ST9
    ST4 --> ST9
    ST5 --> ST9
    ST6 --> ST9
    ST7 --> ST9
    
    ST9 --> ST10[Step 9: ST-10 成果物統合・README]
```

---

### Step 1: [ST-01] 資産棚卸しと技術スタックの確定
⏱️ **実績作業時間**: 6分25秒 ｜ 📄 **成果物**: `docs/reverse-engineering/00-inventory.md`

#### タスクの目的
プロジェクト内の全ファイルを洗い出し、各ファイルの役割、使用されている技術スタック（Java, Tomcat, Ant, PostgreSQL, JDBC等）のバージョンと整合性を確定します。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-01] 資産棚卸しと技術スタックの確定 を実行してください。
ルールと制約:
1. コマンド実行（Docker/Ant/curl等）は行わず、静的ファイル読み取りのみで調査してください。
2. 記述内容には必ず根拠（[src: ファイル:行番号]）を明示してください。
3. 未確定・実機依存事項は Q-001 から始まる要確認番号（[Q-xxx]）を採番し、文書末尾の要確認表に記載してください。
4. 成果物は docs/reverse-engineering/00-inventory.md に作成してください。
5. 既存資料（BasicDesign.html, AboutThisProject.html, .bob/artifacts/*.html）は一切参照しないでください。
```

#### 確認・レビューのポイント
- [ ] 全41ファイル/ディレクトリの役割が過不足なく一覧化されているか。
- [ ] Java 1.4（`source/target="1.4"`）と実行環境 JDK 7 のクロスコンパイル関係が明記されているか。
- [ ] PostgreSQL 9.6 と JDBC3 ドライバ（8.4-702）のバージョンギャップが指摘されているか。

---

### Step 2: [ST-02] アーキテクチャとコンポーネント依存の復元
⏱️ **実績作業時間**: 3分49秒 ｜ 📄 **成果物**: `docs/reverse-engineering/01-architecture.md`

#### タスクの目的
Servlet・DAO・JSP・Model 間の呼び出し関係を分析し、Model 2 (MVC) アーキテクチャのレイヤー構造とコンポーネント依存図を復元します。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-02] アーキテクチャとコンポーネント依存の復元 を実行してください。
ルールと制約:
1. 前タスク ST-01 の成果物およびソースコードを静的に読み取って作成してください。
2. レイヤー構成（Servlet → DAO → DB、Servlet → JSP）を図表で整理してください。
3. Service層、Filter、Listener、共通基底クラスの有無を明確にしてください。
4. 記述内容には必ず根拠（[src: ファイル:行番号]）を明記し、未確定事項は前タスクからの続きの Q 番号を採番してください。
5. 成果物は docs/reverse-engineering/01-architecture.md に作成してください。
```

#### 確認・レビューのポイント
- [ ] クライアント → Servlet → DAO → Database の一方向依存が Mermaid 図等で整理されているか。
- [ ] `Service` 層や共通ユーティリティが存在せず、Servlet が直接 DAO をインスタンス化している事実が記録されているか。

---

### Step 3: [ST-03] 振る舞い（機能・処理フロー・業務ルール）の復元
⏱️ **実績作業時間**: 4分35秒 ｜ 📄 **成果物**: `docs/reverse-engineering/02-behavior.md`

#### タスクの目的
各エンドポイント（`/list`, `/update`, `/delete`, `/`）の HTTP メソッド、入力パラメータ、バリデーション、処理フロー（PRG パターン）、業務ルール（暗黙仕様含む）を定義します。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-03] 振る舞い（機能・処理フロー・業務ルール）の復元 を実行してください。
ルールと制約:
1. web.xml の URL マッピングと各 Servlet の処理ロジックを静的解析してください。
2. 各エンドポイントの仕様（パラメータ、バリデーション、DAO呼出、遷移先）をテーブル形式でまとめてください。
3. 暗黙の仕様（title.trim() が空の場合の無視、id が null/非数値の場合の挙動、トグル更新の NOT done 等）を漏れなく抽出してください。
4. 処理シーケンス図（一覧表示、追加、完了トグル、削除）を Mermaid で記述してください。
5. 成果物は docs/reverse-engineering/02-behavior.md に作成してください。
```

#### 確認・レビューのポイント
- [ ] POST 処理後に `/list` へリダイレクトする PRG (Post-Redirect-Get) パターンが記載されているか。
- [ ] 空白文字のみの登録時の無視処理や、削除時の物理削除ルールが明確化されているか。

---

### Step 4: [ST-04] データ設計の復元
⏱️ **実績作業時間**: 3分35秒 ｜ 📄 **成果物**: `docs/reverse-engineering/03-data.md`

#### タスクの目的
`sql/init.sql` と `TodoDAO.java`、`Todo.java` から、テーブル定義、カラム制約、Java プロパティとのデータ型マッピング、発行される全 SQL 文を復元します。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-04] データ設計の復元 を実行してください。
ルールと制約:
1. sql/init.sql、TodoDAO.java、Todo.java、docker-compose.yml を静的解析してください。
2. todos テーブルの定義、制約、デフォルト値、ER図を作成してください。
3. テーブルカラムと Java フィールド（Todo クラス）の型変換マッピング表を作成してください。
4. DAO で発行される 4 つの SQL 文とパラメータバインド一覧を整理してください。
5. コネクション管理方式（DriverManager、ハードコード接続情報、プールなし）の現状を記録してください。
6. 成果物は docs/reverse-engineering/03-data.md に作成してください。
```

#### 確認・レビューのポイント
- [ ] `todos` テーブルのカラム（`id`, `title`, `done`, `created_at`）と型が正しく定義されているか。
- [ ] `VARCHAR(200)` に対するアプリ層での文字数制限バリデーションの欠落が指摘されているか。

---

### Step 5: [ST-05] 画面設計と文字コード処理の復元
⏱️ **実績作業時間**: 3分40秒 ｜ 📄 **成果物**: `docs/reverse-engineering/04-ui-encoding.md`

#### タスクの目的
JSP ファイル（`list.jsp`, `index.jsp`, `error.jsp`）の画面レイアウト、フォーム・ボタン仕様、打消し線表示等の条件分岐、およびシステム全体の UTF-8 文字コード伝播経路を解明します。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-05] 画面設計と文字コード処理の復元 を実行してください。
ルールと制約:
1. web/ 配下の JSP ファイルと Dockerfile を静的解析してください。
2. list.jsp の表示項目、各フォーム（追加、トグル、削除）、CSS スタイル（HTML 4.01 / IE7 互換）を整理してください。
3. システム全体における UTF-8 文字コードの設定経路（javac -encoding, JSP pageEncoding, Servlet setCharacterEncoding, Dockerfile sed 注入）を網羅してください。
4. JSP 内の未エスケープ <%= %> 出力（XSS 脆弱性リスク）を特定してください。
5. 成果物は docs/reverse-engineering/04-ui-encoding.md に作成してください。
```

#### 確認・レビューのポイント
- [ ] `list.jsp` でのスクリプトレット `<% %>` および `<%= %>` による直出力（XSS リスク）が特定されているか。
- [ ] Dockerfile 内で `server.xml` に `URIEncoding="UTF-8"` を `sed` で注入している工夫が記録されているか。

---

### Step 6: [ST-06] エラー処理と非機能の現状把握
⏱️ **実績作業時間**: 4分02秒 ｜ 📄 **成果物**: `docs/reverse-engineering/05-error-nfr.md`

#### タスクの目的
例外発生時の伝播ルート、Servlet 2.4 仕様に基づくエラーページ遷移規則、リソース解放（空 catch）の実態、およびセキュリティ・運用面の非機能要件の現状をチェックします。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-06] エラー処理と非機能の現状把握 を実行してください。
ルールと制約:
1. TodoDAO、各 Servlet、web.xml の error-page、error.jsp を静的解析してください。
2. 例外フロー（SQLException / NumberFormatException → ServletException → error-page → error.jsp）を図表化してください。
3. DAO の finally ブロック内に存在する空 catch による例外握り潰し（計 9 箇所）を一覧化してください。
4. 非機能チェックリスト（認証/認可、CSRF、XSS、コネクションプール、ロギング、外部設定）を作成してください。
5. 成果物は docs/reverse-engineering/05-error-nfr.md に作成してください。
```

#### 確認・レビューのポイント
- [ ] `finally` ブロック内で `rs/ps/conn` を閉じる際の 9 箇所の空 catch が正確にリストアップされているか。
- [ ] 認証・認可なし、CSRF トークンなし、ロギング機構なしなどの非機能面の現状がチェックリスト化されているか。

---

### Step 7: [ST-07] ビルド・デプロイ構成の復元（静的解析）
⏱️ **実績作業時間**: 4分24秒 ｜ 📄 **成果物**: `docs/reverse-engineering/06-infra-build.md`

#### タスクの目的
`build.xml`、`Dockerfile`、`docker-compose.yml` を読み解き、Ant によるビルドターゲット構造、Docker マルチステージビルド、コンテナ連携と起動順序、ローカル環境単体でビルドできない要因を整理します。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-07] ビルド・デプロイ構成の復元（静的読み取りのみ） を実行してください。
ルールと制約:
1. build.xml、Dockerfile、docker-compose.yml を静的解析してください。
2. Ant ターゲット（init, compile, war, clean）と classpath の依存関係を記述してください。
3. build.xml 内の tomcat.lib パスがコンテナ内固定パスであるため、ローカルで ant war が失敗する理由を明記してください。
4. Docker マルチステージビルド（builder / runtime）と compose のヘルスチェック・起動順序を Mermaid 図で整理してください。
5. 外部アーカイブ（archive.apache.org）取得依存のリスクを記録してください。
6. 成果物は docs/reverse-engineering/06-infra-build.md に作成してください。
```

#### 確認・レビューのポイント
- [ ] `build.xml` の `tomcat.lib=/opt/tomcat/common/lib` が原因でローカル実行できない構造的理由が明確か。
- [ ] Docker Compose の `depends_on: condition: service_healthy` による DB 起動待ち制御が図解されているか。

---

### Step 8: [ST-09] モダナイズ課題・リスク一覧の作成
⏱️ **実績作業時間**: 4分28秒 ｜ 📄 **成果物**: `docs/reverse-engineering/07-modernization-risks.md`

#### タスクの目的
ST-01 〜 ST-07 で復元された全知見を統合し、将来のモダナイズ（Java 17/21, Spring Boot / Quarkus / Liberty, Jakarta EE, コンテナ化）に向けた課題・リスクを、重大度・難易度・影響範囲・推奨対応方針付きでマトリクス化します。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-09] モダナイズ課題・リスク一覧の作成 を実行してください。
ルールと制約:
1. ST-01 〜 ST-07 の全成果物（docs/reverse-engineering/00〜06）をインプットとして統合分析してください。
2. 課題・リスクをカテゴリ別（セキュリティ、互換性・実行基盤、ビルド・DevOps、コード品質、データアクセス）に整理してください。
3. 各課題に根拠（[src:] / [spec:] / [Q-xxx]）、重大度（影響×確度）、難易度（高/中/低）、影響範囲（波及ファイル）、対応方針候補を付与してください。
4. EOL コンポーネント情報（Tomcat 5.5, PostgreSQL 9.6, Java 7 等）を網羅してください。
5. 移行前後の振る舞い確認用受け入れテスト項目リストを作成してください。
6. 成果物は docs/reverse-engineering/07-modernization-risks.md に作成してください。
```

#### 確認・レビューのポイント
- [ ] セキュリティ（XSS, CSRF, 認証, 平文パスワード）、互換性（`javax` → `jakarta`、Java 1.4 raw types）、基盤（EOL）が網羅されているか。
- [ ] 優先度順のモダナイズロードマップ（ビルド刷新 → ランタイム更新 → セキュリティ強化 → コード刷新）が提示されているか。

---

### Step 9: [ST-10] 成果物の統合とレビュー・README作成
⏱️ **実績作業時間**: 4分29秒 ｜ 📄 **成果物**: `docs/reverse-engineering/README.md`

#### タスクの目的
全設計書（00 〜 07）のクロスチェック、行番号参照の整合性検証（抜き取りチェック）、要確認事項（Q-001 〜 Q-017）の統合管理表作成、および全体サマリ目次としての `README.md` を完成させます。

#### 入力プロンプト
```text
@reverse-engineering-task-cards.md の [ST-10] 成果物の統合とレビュー を実行してください。
ルールと制約:
1. docs/reverse-engineering/ 配下の全成果物（00〜07）を精読し、用語・バージョン・URLの表記揺れをクロスチェックしてください。
2. 各成果物の [src: ファイル:行番号] を抜き取りで最低 3 件ずつ実コードと照合し、行番号の整合性を検証してください。
3. 各成果物末尾の Q 番号（Q-001 〜 Q-017）を重複・欠番なく集約した統合要確認一覧表を作成してください。
4. 全体の目次、システム要約、主要リスク TOP5 への導線を含む docs/reverse-engineering/README.md を作成してください。
```

#### 確認・レビューのポイント
- [ ] `README.md` を開くだけで、システム全体の仕様・構造・リスク・要確認事項へ即座にアクセスできるハブになっているか。
- [ ] Q-001 から Q-017 までの全 17 件の要確認事項が理由・確認方法付きで一元管理されているか。

---

## 5. ハンズオンの振り返りとモダナイズ次のステップ

### 5.1 AIリバースエンジニアリングの成果
わずか **約32分** の作業で、設計書が存在しなかったレガシーシステムから、以下の高品質な資産を復元できました：
1. **完全なドキュメント体系**: 8 つのマークダウン設計書（約2,500行以上）
2. **250箇所以上の根拠明記**: `[src: file:line]` 形式による正確なソーストレーサビリティ
3. **17件の要確認リスト**: 動的検証・環境依存事項の明確な切り分け
4. **16件のモダナイズ課題マトリクス**: 優先度・難易度付きの改修計画

### 5.2 次のフェーズ: モダナイズ実装へ
本リバースエンジニアリング成果物をベースに、以下の順序でモダナイズを進めることが推奨されます：
1. **ビルド刷新**: Ant から Maven / Gradle への移行（依存関係の宣言的解決）
2. **ランタイム・プラットフォーム刷新**: Java 17/21 + Tomcat 10+ (Jakarta EE) または Open Liberty / Quarkus への移行
3. **セキュリティ強化**: 出力エスケープ（XSS対応）、CSRFトークン導入、DB接続情報の外部化（環境変数/Secret）
4. **コードモダナイズ**: ジェネリクス適用、DAOのコネクションプール化（HikariCP等）、トランザクション境界の設定
5. **自動テストの導入**: JUnit 5 + Testcontainers による回帰テスト基盤の構築
