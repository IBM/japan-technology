# リバースエンジニアリング実行タスクカード（Docker 不使用版） — ClassicJava201 Todo アプリ

> 本書は [`reverse-engineering-plan-no-docker.md`](reverse-engineering-plan-no-docker.md) を実行するためのタスクカード一覧です。
> コマンド実行（Docker / Ant / javac / curl 等）を行わず、ソースコードと公式仕様の静的読み取りのみでリバースエンジニアリングを実施します。

---

## 1. 共通実行ルール・制約

1. **コマンド実行の禁止**: `docker`, `ant`, `curl`, `javac` などの CLI コマンド実行は一切行わない。
2. **根拠の明記**:
   - ソースコード: `[src: ファイルパス:行番号]`（例: `[src: src/com/example/todo/dao/TodoDAO.java:19]`）
   - 公式仕様: `[spec: URL 節番号]`（URL を取得・確認できたもののみ）
   - 実機依存・未確定事項: `[Q-xxx]`（全タスク共通の連番 `Q-001`〜、各文書末尾に要確認表を配置）
3. **参照禁止資産の遵守**:
   - `BasicDesign.html`, `AboutThisProject.html`, `.bob/artifacts/*.html` は**開かない・読まない**。
4. **進行手順**:
   - 原則 1 サブタスクずつ実施する。
   - 成果物作成後、[`reverse-engineering-plan-no-docker.md`](reverse-engineering-plan-no-docker.md) の該当サブタスクの Status、最終採番 Q 番号、申し送りを更新し、ユーザーの確認を受ける。

---

## 2. タスク依存関係

```mermaid
graph TD
    ST1[ST1: 資産棚卸しと技術スタック] --> ST2[ST2: アーキテクチャ・依存関係]
    ST1 --> ST3[ST3: 振る舞い・業務ルール]
    ST1 --> ST4[ST4: データ設計]
    ST1 --> ST5[ST5: 画面設計・文字コード]
    ST1 --> ST6[ST6: エラー処理・非機能]
    ST1 --> ST7[ST7: ビルド・デプロイ静的解析]
    
    ST2 --> ST9[ST9: モダナイズ課題・リスク]
    ST3 --> ST9
    ST4 --> ST9
    ST5 --> ST9
    ST6 --> ST9
    ST7 --> ST9
    
    ST9 --> ST10[ST10: 成果物統合・README]
```

---

## 3. タスクカード詳細

### 📋 [ST-01] 資産棚卸しと技術スタックの確定
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/00-inventory.md`
- **前提タスク**: なし（最優先着手）
- **対象ファイル**:
  - [`build.xml`](build.xml)
  - [`Dockerfile`](Dockerfile)
  - [`docker-compose.yml`](docker-compose.yml)
  - [`web/WEB-INF/web.xml`](web/WEB-INF/web.xml)
  - `lib/`
- **作業項目**:
  1. ディレクトリ配下の全ファイルを列挙し役割を 1 行で記述（参照禁止・対象外ファイルは区分と名前のみ記載、内容は読まない）。
  2. 設定ファイルからバージョン情報を抽出（`source/target` 1.4、JDK 7、Tomcat 5.5.36、Ant 1.9.16、PostgreSQL 9.6、Servlet 2.4、JDBC3 ドライバ）。
  3. 宣言バージョンの食い違い・組み合わせの整理（JDK 7 とターゲット 1.4 の関係、JDBC3 8.4 と PostgreSQL 9.6 の互換性など）。
  4. 計画書 5.1/5.2 の結論（Tomcat 5.5 / Ant 1.9.16 / OpenJDK 7）を反映。
  5. `00-inventory.md` を作成し、最後に使った `Q-xxx` 番号を計画書に記録。

---

### 📋 [ST-02] アーキテクチャとコンポーネント依存の復元
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/01-architecture.md`
- **前提タスク**: ST-01
- **対象ファイル**:
  - [`src/com/example/todo/dao/TodoDAO.java`](src/com/example/todo/dao/TodoDAO.java)
  - [`src/com/example/todo/model/Todo.java`](src/com/example/todo/model/Todo.java)
  - [`src/com/example/todo/servlet/TodoListServlet.java`](src/com/example/todo/servlet/TodoListServlet.java)
  - [`src/com/example/todo/servlet/TodoUpdateServlet.java`](src/com/example/todo/servlet/TodoUpdateServlet.java)
  - [`src/com/example/todo/servlet/TodoDeleteServlet.java`](src/com/example/todo/servlet/TodoDeleteServlet.java)
  - [`web/list.jsp`](web/list.jsp)
- **作業項目**:
  1. レイヤー構成（Servlet → DAO → DB、Servlet → JSP）を図・表で整理。
  2. 各 Servlet が呼び出す DAO メソッド、forward / redirect 先の一覧化。
  3. Java 内および JSP（`list.jsp` での `Todo` クラス import、`request` 属性 `todos`）の結合点を特定。
  4. Service 層・共通基底クラス・Filter・Listener の有無の確認。
  5. DAO のライフサイクル（毎回 `new`、ステートレス）と HttpServlet 継承関係の明記。
  6. `01-architecture.md` を作成。

---

### 📋 [ST-03] 振る舞い（機能・処理フロー・業務ルール）の復元
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/02-behavior.md`
- **前提タスク**: ST-01
- **対象ファイル**:
  - [`web/WEB-INF/web.xml`](web/WEB-INF/web.xml)
  - `src/com/example/todo/servlet/*`
  - [`web/index.jsp`](web/index.jsp)
  - [`web/list.jsp`](web/list.jsp)
- **作業項目**:
  1. URL マッピングと Servlet の対応表を作成。
  2. 各エンドポイントの HTTP メソッド、パラメータ、バリデーション、DAO 呼出、遷移先を記述。
  3. シーケンス図（一覧表示、追加、完了トグル、削除）を作成。
  4. 暗黙の仕様を整理（`title.trim()` が空なら無視、`id` が `null` 時の挙動、トグル時の `NOT done` など）。
  5. `welcome-file-list` の未定義、未実装メソッド（GET `/update` 等）の挙動、`list.jsp` 直接アクセス時の挙動を `Q-xxx` として記録。
  6. `02-behavior.md` を作成。

---

### 📋 [ST-04] データ設計の復元
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/03-data.md`
- **前提タスク**: ST-01
- **対象ファイル**:
  - [`sql/init.sql`](sql/init.sql)
  - [`src/com/example/todo/dao/TodoDAO.java`](src/com/example/todo/dao/TodoDAO.java)
  - [`src/com/example/todo/model/Todo.java`](src/com/example/todo/model/Todo.java)
  - [`docker-compose.yml`](docker-compose.yml)
- **作業項目**:
  1. `init.sql` からテーブル定義（`todos` テーブル）、カラム、制約、デフォルト値を抽出して ER 図・テーブル定義表を作成。
  2. `Todo` モデルのフィールド型と `ResultSet` / SQL 型のマッピング表を作成。
  3. DAO の 4 メソッド（findAll, insert, toggleDone, delete）の SQL とパラメータバインドを一覧化。
  4. `VARCHAR(200)` 長さ検証の有無、`SERIAL` と Java `int` 範囲の整合性、インデックス有無を整理。
  5. `docker-compose.yml` から `init.sql` の初期化条件（空データ時のみ実行）を記述。
  6. DB 接続方式（`DriverManager`、ハードコード接続情報、`static` ブロック）を記録。
  7. `03-data.md` を作成。

---

### 📋 [ST-05] 画面設計と文字コード処理の復元
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/04-ui-encoding.md`
- **前提タスク**: ST-01
- **対象ファイル**:
  - [`web/list.jsp`](web/list.jsp)
  - [`web/index.jsp`](web/index.jsp)
  - [`web/error.jsp`](web/error.jsp)
  - [`Dockerfile`](Dockerfile)
- **作業項目**:
  1. 画面一覧、`list.jsp` の表示項目、フォーム（action/method/hidden）、完了状態ごとの打消し線表示等の条件分岐を整理。
  2. `index.jsp`（`/list` へのリダイレクト）、`error.jsp` の役割を記述。
  3. HTML 仕様（HTML 4.01 Transitional、IE7 互換 meta、インライン CSS）を記録。
  4. 文字コード経路（`javac -encoding UTF-8`、JSP `pageEncoding`、Servlet `setCharacterEncoding`、Dockerfile の `sed` による `URIEncoding="UTF-8"` 注入）の網羅。
  5. 日本語入力・保存の実機依存挙動を `Q-xxx` として記録。
  6. `04-ui-encoding.md` を作成。

---

### 📋 [ST-06] エラー処理と非機能の現状把握
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/05-error-nfr.md`
- **前提タスク**: ST-01
- **対象ファイル**:
  - [`src/com/example/todo/dao/TodoDAO.java`](src/com/example/todo/dao/TodoDAO.java)
  - `src/com/example/todo/servlet/*`
  - [`web/error.jsp`](web/error.jsp)
  - [`web/WEB-INF/web.xml`](web/WEB-INF/web.xml)
- **作業項目**:
  1. 例外フロー（`SQLException`, `NumberFormatException`, `ClassNotFoundException` → `ServletException` ラップ → `error-page` 遷移）を追跡・図表化。
  2. `finally` 内の空 `catch` による例外握り潰し箇所の列挙。
  3. Servlet 2.4 仕様（SRV.9.9.2）に基づく `error-page` 照合規則と `error.jsp` の表示内容の整理。
  4. `TodoDAO` の `static` 初期化ブロックの実行タイミング（JLS §12.4.1）の記述。
  5. 非機能観点チェックリスト（認証/認可なし、CSRF なし、XSS 未対策 `<%= %>`、コネクションプールなし、ログ出力なし、外部設定なし）の作成。
  6. `05-error-nfr.md` を作成。

---

### 📋 [ST-07] ビルド・デプロイ構成の復元（静的読み取りのみ）
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/06-infra-build.md`
- **前提タスク**: ST-01
- **対象ファイル**:
  - [`build.xml`](build.xml)
  - [`Dockerfile`](Dockerfile)
  - [`docker-compose.yml`](docker-compose.yml)
- **作業項目**:
  1. Ant ビルドターゲット（`init`, `compile`, `war`, `clean`）と classpath 構成の記述。
  2. `build.xml` の `tomcat.lib` パスによりローカル単体で `ant war` が失敗する要因を静的解析。
  3. Docker マルチステージビルド（builder / runtime）と WAR コピー経路の復元。
  4. `docker-compose.yml` のネットワーク、ボリューム、`db` の healthcheck、`depends_on: service_healthy`、`restart: on-failure` の整理。
  5. 外部アーカイブ依存（archive.apache.org）やプラットフォーム固定（`linux/amd64`）のリスクを記録。
  6. 実際のビルド・起動成否は `Q-xxx` として記録。
  7. `06-infra-build.md` を作成。

---

### 📋 [ST-08] スキップ（対象外）
- **ステータス**: `[-] skipped`（既存設計資料との突き合わせは行わない）

---

### 📋 [ST-09] モダナイズ課題・リスク一覧の作成
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/07-modernization-risks.md`
- **前提タスク**: ST-01 〜 ST-07
- **対象ファイル**: ST-01〜ST-07 の全成果物
- **作業項目**:
  1. 各領域（セキュリティ、互換性、ビルド、実行基盤、コード品質、データ、テスト）から課題・リスクを網羅的に抽出。
  2. 各課題に根拠（`[src:]` / `[spec:]` / `[Q-xxx]`）、影響範囲（波及ファイル）、対応方針候補を付与。
  3. 重大度を「影響（高/中/低） × 確度（確定/暫定）」および「難易度（高/中/低）」で評価。
  4. EOL 情報（Tomcat 5.5, PostgreSQL 9.6, Java 7, Ant 1.9 等）の整理。
  5. 移行後の振る舞い比較用受け入れ確認項目リスト、および移行前実機確認項目リスト（`Q-xxx` 集約）を作成。
  6. `07-modernization-risks.md` を作成。

---

### 📋 [ST-10] 成果物の統合とレビュー
- **ステータス**: `[ ] todo`
- **成果物**: `docs/reverse-engineering/README.md`
- **前提タスク**: ST-01 〜 ST-09
- **対象ファイル**: `docs/reverse-engineering/` 配下の全成果物
- **作業項目**:
  1. 全成果物の用語、URL、クラス名、バージョンのクロスチェックと表記統一。
  2. `[src: ファイル:行]` の抜き取り検証（各文書最低 3 件以上、行番号の整合確認）。
  3. 各文書末尾の「要確認」表の ID（`Q-001`〜）を集約し、重複・欠番のない統合要確認表を作成。
  4. `README.md`（目次、システム概要、主要リスク導線、要確認一覧）を作成。
  5. 最終レビューとユーザー承認の受領。
