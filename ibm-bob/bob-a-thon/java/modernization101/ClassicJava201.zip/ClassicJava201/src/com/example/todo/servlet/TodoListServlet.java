package com.example.todo.servlet;

import com.example.todo.dao.TodoDAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TodoListServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List todos = new TodoDAO().findAll();
            request.setAttribute("todos", todos);
            request.getRequestDispatcher("/list.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String title = request.getParameter("title");
        if (title != null && title.trim().length() > 0) {
            try {
                new TodoDAO().insert(title.trim());
            } catch (SQLException e) {
                throw new ServletException(e);
            }
        }
        response.sendRedirect(request.getContextPath() + "/list");
    }
}
