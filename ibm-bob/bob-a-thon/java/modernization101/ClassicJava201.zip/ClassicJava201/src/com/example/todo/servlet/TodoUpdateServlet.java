package com.example.todo.servlet;

import com.example.todo.dao.TodoDAO;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TodoUpdateServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String idParam = request.getParameter("id");
        if (idParam != null) {
            try {
                int id = Integer.parseInt(idParam);
                new TodoDAO().updateDone(id);
            } catch (NumberFormatException e) {
                throw new ServletException("Invalid id: " + idParam, e);
            } catch (SQLException e) {
                throw new ServletException(e);
            }
        }
        response.sendRedirect(request.getContextPath() + "/list");
    }
}
