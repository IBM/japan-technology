package com.example.todo.dao;

import com.example.todo.model.Todo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TodoDAO {

    private static final String JDBC_URL  = "jdbc:postgresql://db:5432/tododb";
    private static final String JDBC_USER = "todouser";
    private static final String JDBC_PASS = "todopass";

    static {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            // ※ static ブロックからのスローは ExceptionInInitializerError にラップされる。
            //    起動ログに "ExceptionInInitializerError" が出た場合は Caused by を確認すること。
            throw new RuntimeException("PostgreSQL JDBC Driver not found", e);
        }
    }

    public List findAll() throws SQLException {
        List list = new ArrayList();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            ps = conn.prepareStatement(
                "SELECT id, title, done, created_at FROM todos ORDER BY id ASC");
            rs = ps.executeQuery();
            while (rs.next()) {
                Todo todo = new Todo();
                todo.setId(rs.getInt("id"));
                todo.setTitle(rs.getString("title"));
                todo.setDone(rs.getBoolean("done"));
                todo.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(todo);
            }
        } finally {
            if (rs   != null) try { rs.close();   } catch (SQLException e) {}
            if (ps   != null) try { ps.close();   } catch (SQLException e) {}
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
        return list;
    }

    public void insert(String title) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            ps = conn.prepareStatement(
                "INSERT INTO todos (title) VALUES (?)");
            ps.setString(1, title);
            ps.executeUpdate();
        } finally {
            if (ps   != null) try { ps.close();   } catch (SQLException e) {}
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }

    public void updateDone(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            ps = conn.prepareStatement(
                "UPDATE todos SET done = NOT done WHERE id = ?");
            ps.setInt(1, id);
            ps.executeUpdate();
        } finally {
            if (ps   != null) try { ps.close();   } catch (SQLException e) {}
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }

    public void delete(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            ps = conn.prepareStatement(
                "DELETE FROM todos WHERE id = ?");
            ps.setInt(1, id);
            ps.executeUpdate();
        } finally {
            if (ps   != null) try { ps.close();   } catch (SQLException e) {}
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
}
