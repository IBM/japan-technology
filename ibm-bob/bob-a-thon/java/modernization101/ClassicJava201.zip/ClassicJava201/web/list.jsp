<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
         import="java.util.List, java.util.Iterator, com.example.todo.model.Todo" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>TODO リスト</title>
<style type="text/css">
body { font-family: "MS Gothic", monospace; font-size: 13px; margin: 20px; }
h1 { font-size: 16px; }
table { border-collapse: collapse; width: 600px; }
th, td { border: 1px solid #999999; padding: 4px 8px; text-align: left; }
th { background-color: #cccccc; }
.done-text { text-decoration: line-through; color: #999999; }
input[type="text"] { width: 300px; }
</style>
</head>
<body>
<h1>TODO リスト</h1>

<form method="POST" action="<%= request.getContextPath() %>/list">
  <input type="text" name="title" value="">
  <input type="submit" value="追加">
</form>

<br>

<table>
  <tr>
    <th>ID</th>
    <th>タイトル</th>
    <th>作成日時</th>
    <th>完了</th>
    <th>削除</th>
  </tr>
<%
List todos = (List) request.getAttribute("todos");
Iterator it = todos.iterator();
while (it.hasNext()) {
    Todo todo = (Todo) it.next();
%>
  <tr>
    <td><%= todo.getId() %></td>
    <td><%= todo.isDone() ? "<span class=\"done-text\">" + todo.getTitle() + "</span>" : todo.getTitle() %></td>
    <td><%= todo.getCreatedAt() %></td>
    <td>
      <form method="POST" action="<%= request.getContextPath() %>/update">
        <input type="hidden" name="id" value="<%= todo.getId() %>">
        <input type="submit" value="<%= todo.isDone() ? "未完了に戻す" : "完了にする" %>">
      </form>
    </td>
    <td>
      <form method="POST" action="<%= request.getContextPath() %>/delete">
        <input type="hidden" name="id" value="<%= todo.getId() %>">
        <input type="submit" value="削除">
      </form>
    </td>
  </tr>
<% } %>
</table>

</body>
</html>
