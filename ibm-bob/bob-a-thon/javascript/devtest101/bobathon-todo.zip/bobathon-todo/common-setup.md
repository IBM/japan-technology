# 共通準備(Bob の準備と作業フォルダ)

シナリオ1(ブラウザ)・シナリオ2(Node.js)のどちらでも、最初にここを済ませます。

## 1. Bob のインストールとサインイン

1. [Bob の公式インストール手順](https://bob.ibm.com/docs/ide/getting-started/install)に従って、Bob をインストールします。
2. Bob を起動し、ブラウザで表示される画面から **IBMid** でサインインします。IBMid がない場合の作成方法は、上記の手順書にリンクがあります。
3. サインインが終わったら Bob に戻ります。

## 2. ネットワークに制限がある場合

会社のネットワークなどで Bob に接続できない場合は、[Bob の公式ドキュメント(ファイアウォール設定)](https://bob.ibm.com/docs/ide/troubleshooting/ts-firewall-rules)を確認して、ネットワーク管理者または IT 担当者に相談してください。

## 3. 作業フォルダを作って Bob で開く

作業フォルダは、この演習のファイルをすべて入れる、空のフォルダです。場所と名前は自由です(例:デスクトップの `bob-todo`)。

| OS | 操作 |
|---|---|
| Windows | エクスプローラーで場所を開き、右クリック → 新規作成 → フォルダー。名前を `bob-todo` にする |
| macOS | Finder で場所を開き、右クリック → 新規フォルダ。名前を `bob-todo` にする |

次に、作ったフォルダを Bob で開きます。

- Bob のメニューから **[ファイル] > [フォルダーを開く...]** を選び、`bob-todo` を選びます。
- 「フォルダ内のファイルの作成者を信頼しますか」のような確認が出たら、自分で作った空のフォルダなので、信頼する側を選びます。

## 4. Bob のチャットを開いて Agent モードにする

1. チャットが見えていない場合は、次のショートカットで開きます。

   | OS | 操作 |
   |---|---|
   | Windows | `Ctrl + Alt + B` |
   | macOS | `Option + Command + B` |

2. チャット入力欄の左にあるモード選択のドロップダウンを開き、**Agent** を選びます。チャットに `/agent` と入力しても切り替えられます。
3. 画面右下の `Permissions` で、自動承認が **Read のみ**になっていることを確認します。コマンドの実行やファイルの変更は、そのつど Bob が確認を求めます。

> Bob が確認を求めてきたときは、内容を読んでから承認してください。この演習では、Execute(コマンド実行)の自動承認は使いません。

## 5. バグ入りファイルの差し替え

演習の途中（手順書の指示があったタイミング）で、zip を展開した `bobathon-todo` フォルダの中にあるバグ入りのファイルを、作業フォルダに上書きコピーします。

### zip の入手

下の URL をブラウザで開き、`bobathon-todo.zip` をダウンロードして展開(解凍)してください。展開すると `bobathon-todo` フォルダができます。演習の前に済ませておくと安心です。

[https://github.com/IBM/japan-technology/blob/main/ibm-bob/bobathon-support/js101/bobathon-todo.zip](https://github.com/IBM/japan-technology/blob/main/ibm-bob/bobathon-support/js101/bobathon-todo.zip)

| OS | 展開の操作 |
|---|---|
| Windows | zip ファイルを右クリック → 「すべて展開」 |
| macOS | zip ファイルをダブルクリック |

### 差し替えるファイル

| シナリオ | コピー元 | コピー先(作業フォルダ) |
|---|---|---|
| シナリオ1 | `bobathon-todo/scenario1-browser/bug/todo-logic.js` | `todo-logic.js` |
| シナリオ2 | `bobathon-todo/scenario2-nodejs/bug/todo.js` | `todo.js` |

### コピーの手順

| OS | 操作 |
|---|---|
| Windows | エクスプローラーでコピー元のファイルを選択 → コピー → 作業フォルダに貼り付け(上書き) |
| macOS | Finder でコピー元のファイルを選択 → コピー → 作業フォルダに貼り付け(上書き確認が出たら「置き換える」) |

### 確認

- コピー後、作業フォルダのファイル名が `todo-logic.js`（または `todo.js`）のままであることを確認します。
- 迷ったら、講師に声をかけてください。
